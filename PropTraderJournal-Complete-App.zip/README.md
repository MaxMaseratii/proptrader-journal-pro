# PropTraderJournal - Complete Application

## Overview
This is a complete trading journal application built for proprietary trading firms and traders.

## Installation
1. Extract this archive
2. Run: npm install
3. Set up your database with the provided schema
4. Configure environment variables
5. Run: npm run dev

## Features
- Complete trading journal with data persistence
- Account management with projection system
- Risk management and performance analytics
- CSV import functionality
- Comprehensive dashboard with real-time data
- User authentication via Replit Auth

## Architecture
- Frontend: React 18 + TypeScript + Tailwind CSS
- Backend: Node.js + Express + TypeScript
- Database: PostgreSQL with Drizzle ORM
- Authentication: Replit Auth with session management

## Recent Updates (July 16, 2025)
- Implemented comprehensive data persistence across all forms
- Connected projection data to dashboard widgets
- Fixed discipline calculator integration
- Enhanced account selection and data filtering
- Production-ready with proper error handling

For full documentation, see replit.md
