import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  ChartLine, 
  Book, 
  Wallet, 
  Shield, 
  BarChart3, 
  DollarSign, 
  Calendar,
  TrendingUp,
  User,
  Brain,
  LogOut,
  BookOpen,
  CreditCard,
  ChevronRight,
  Trophy,
  Bot,
  Settings
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const navItems = [
  { href: "/projections", label: "Accounts  Risk Management & Target Projection Planning", icon: TrendingUp, section: "main" },
  { href: "/", label: "Dashboard", icon: ChartLine, section: "main" },
  { href: "/trading-companion", label: "Trading Companion", icon: Bot, section: "main" },
  { href: "/trades", label: "Trades", icon: BarChart3, section: "main" },
  { href: "/charts", label: "Trading Charts", icon: TrendingUp, section: "main" },
  { href: "/disciplinary-assistant", label: "MMM Disciplinary Coach", icon: Settings, section: "main" },
  { href: "/journal", label: "Trading Journal", icon: Book, section: "main" },
  { href: "/spending", label: "Prop Spending", icon: CreditCard, section: "main" },
  { href: "/payouts", label: "Payouts", icon: DollarSign, section: "main" },
  { href: "/risk-management", label: "Risk Management", icon: Shield, section: "main" },
  { href: "/achievements", label: "Achievement", icon: Trophy, section: "main" },
  { href: "/analytics", label: "Advanced Analytics", icon: Brain, section: "main" },
  { href: "/reports", label: "Reports", icon: Calendar, section: "profile" },
];

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const mainItems = navItems.filter(item => item.section === "main");
  const profileItems = navItems.filter(item => item.section === "profile");

  return (
    <aside className="w-64 bg-prop-gradient-main border-r border-prop-gold/20 flex-shrink-0">
      <div className="p-6 border-b border-prop-gold/20">
        <div className="flex items-center space-x-3">
          <div className="bg-prop-gradient-rainbow p-3 rounded-xl hover-glow smooth-transition">
            <BookOpen className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-gradient-rainbow">PropTraderJournal</h1>
            <p className="text-xs text-gray-400">Elite Trading Journal</p>
          </div>
        </div>
      </div>
      
      <nav className="mt-6 flex-1 overflow-y-auto pb-20">
        <div className="px-6 mb-4">
          <h3 className="text-xs font-medium text-prop-gold uppercase tracking-wider">Main</h3>
        </div>
        <ul className="space-y-2 px-4">
          {mainItems.map(({ href, label, icon: Icon }) => (
            <li key={href}>
              <Link href={href} className={cn(
                "flex items-center px-4 py-3 text-sm font-medium rounded-xl smooth-transition cursor-pointer group",
                location === href 
                  ? "bg-prop-gradient-gold text-black font-bold" 
                  : "text-gray-300 hover:bg-prop-card hover:text-prop-gold hover-scale"
              )}>
                <Icon className={cn(
                  "mr-3 h-5 w-5 smooth-transition",
                  location === href ? "text-black" : "text-gray-400 group-hover:text-prop-gold"
                )} />
                {label}
              </Link>
            </li>
          ))}
        </ul>
        
        {/* User Profile with just initials */}
        <div className="px-4 mt-8">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className="w-full flex items-center justify-start px-3 py-2 text-sm font-medium text-gray-300 hover:bg-dark-card rounded-lg"
              >
                <div className="mr-3 h-4 w-4 bg-prop-gradient-gold rounded-full flex items-center justify-center text-xs font-bold text-black">
                  {user ? (
                    (user as any)?.firstName?.charAt(0) || 
                    (user as any)?.email?.charAt(0).toUpperCase() || 'U'
                  ) : 'U'}
                </div>
                Profile
              </Button>
            </DropdownMenuTrigger>
            
            <DropdownMenuContent 
              className="w-64 bg-dark-card border-prop-gold/20 shadow-xl" 
              align="start"
              side="right"
            >
              <DropdownMenuLabel className="text-prop-gold">My Account</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-prop-gold/20" />
              
              <DropdownMenuItem 
                className="text-gray-300 hover:bg-dark-surface cursor-pointer"
                onClick={() => window.location.href = '/profile'}
              >
                <User className="mr-2 h-4 w-4 text-blue-400" />
                Profile Settings
              </DropdownMenuItem>
              
              <DropdownMenuItem 
                className="text-gray-300 hover:bg-dark-surface cursor-pointer"
              >
                <Shield className="mr-2 h-4 w-4 text-blue-500" />
                Account Management
              </DropdownMenuItem>
              
              <DropdownMenuItem 
                className="text-gray-300 hover:bg-dark-surface cursor-pointer"
              >
                <CreditCard className="mr-2 h-4 w-4 text-green-400" />
                Billing & Subscription
              </DropdownMenuItem>
              
              <DropdownMenuItem 
                className="text-gray-300 hover:bg-dark-surface cursor-pointer"
              >
                <Shield className="mr-2 h-4 w-4 text-yellow-400" />
                Security Settings
              </DropdownMenuItem>
              
              <DropdownMenuSeparator className="bg-prop-gold/20" />
              
              {/* Reports moved to profile section */}
              {profileItems.map(({ href, label, icon: Icon }) => (
                <DropdownMenuItem 
                  key={href}
                  className="text-gray-300 hover:bg-dark-surface cursor-pointer"
                  onClick={() => window.location.href = href}
                >
                  <Icon className="mr-2 h-4 w-4 text-prop-gold" />
                  {label}
                </DropdownMenuItem>
              ))}
              
              <DropdownMenuSeparator className="bg-prop-gold/20" />
              
              <DropdownMenuItem 
                className="text-red-400 hover:bg-red-600/20 cursor-pointer"
                onClick={() => window.location.href = '/api/logout'}
              >
                <LogOut className="mr-2 h-4 w-4 text-red-400" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </nav>
    </aside>
  );
}
