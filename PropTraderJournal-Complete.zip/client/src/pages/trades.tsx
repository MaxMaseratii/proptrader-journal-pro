import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, CalendarDays, Download, Filter, Search, Plus, Edit3, Save, X, Upload, FileText, AlertCircle, CheckCircle, Target, RotateCcw } from "lucide-react";
import { Label } from "@/components/ui/label";
import { formatCurrency, formatDate } from "@/lib/utils";
import { getUniversalValueColor, getPercentageColor, getStatusColor } from "@/lib/colorUtils";
import type { Trade, Account } from "@shared/schema";
import { useState, useMemo, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import TradeDetailModal from "@/components/trade-detail-modal";

import * as XLSX from 'xlsx';

// Format price levels (not currency)
const formatPrice = (price: number): string => {
  return price.toFixed(2);
};

// Helper function to format time for CSV
const formatTimeForCSV = (timestamp: Date | string | null): string => {
  if (!timestamp) return 'Not recorded';
  const date = timestamp instanceof Date ? timestamp : new Date(timestamp);
  return date.toLocaleString('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
};

// Helper function to get contract multiplier for accurate P&L calculation - CRITICAL FIX
const getContractMultiplier = (symbol: string): number => {
  const symbolUpper = symbol.toUpperCase();
  console.log(`🔍 Getting multiplier for symbol: ${symbol} (upper: ${symbolUpper})`);
  
  // CRITICAL: MES must be checked BEFORE ES to avoid wrong matching
  if (symbolUpper.includes('MES')) {
    console.log(`✅ MES detected: returning multiplier 5`);
    return 5; // Micro E-mini S&P 500: $5 per point
  }
  if (symbolUpper.includes('ESU') || (symbolUpper.includes('ES') && !symbolUpper.includes('MES'))) {
    console.log(`✅ ES detected: returning multiplier 50`);
    return 50; // E-mini S&P 500: $50 per point
  }
  if (symbolUpper.includes('MNQ')) {
    console.log(`✅ MNQ detected: returning multiplier 2`);
    return 2; // Micro E-mini NASDAQ: $2 per point
  }
  if (symbolUpper.includes('NQ') && !symbolUpper.includes('MNQ')) {
    console.log(`✅ NQ detected: returning multiplier 20`);
    return 20; // E-mini NASDAQ: $20 per point
  }
  if (symbolUpper.includes('YM')) {
    console.log(`✅ YM detected: returning multiplier 5`);
    return 5; // E-mini Dow: $5 per point
  }
  if (symbolUpper.includes('RTY')) {
    console.log(`✅ RTY detected: returning multiplier 50`);
    return 50; // E-mini Russell 2000: $50 per point
  }
  
  console.warn(`⚠️ Unknown symbol multiplier for ${symbol}, using 1`);
  return 1; // Default multiplier for unknown contracts
};

// Helper function to calculate duration for CSV
const calculateDurationForCSV = (trade: Trade): string => {
  if (!trade.fillTime) return 'No entry time';
  
  const entryTime = new Date(trade.fillTime);
  let exitTime;
  
  // Priority 1: Use actual exitTime if available
  if (trade.exitTime) {
    exitTime = new Date(trade.exitTime);
  }
  // Priority 2: For closed trades without exitTime, try to estimate from trade date + some time
  else if (trade.status === 'closed' && trade.exitPrice) {
    // Since we don't have exact exit time, we can't calculate precise duration
    return 'Exit time not recorded';
  }
  // Priority 3: Open trades show "Open"
  else {
    return trade.status === 'open' ? 'Currently open' : 'No timing data';
  }
  
  // Calculate actual duration from real timestamps
  const durationMs = exitTime.getTime() - entryTime.getTime();
  const durationMinutes = Math.max(1, Math.floor(durationMs / (1000 * 60)));
  
  if (durationMinutes < 60) {
    return `${durationMinutes}m`;
  } else if (durationMinutes < 1440) { // Less than 24 hours
    const hours = Math.floor(durationMinutes / 60);
    const mins = durationMinutes % 60;
    return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  } else {
    const days = Math.floor(durationMinutes / 1440);
    const hours = Math.floor((durationMinutes % 1440) / 60);
    return hours > 0 ? `${days}d ${hours}h` : `${days}d`;
  }
};

// Enhanced import statistics interface for AI-powered detection
interface ImportStats {
  imported: number;
  errors: number;
  longTrades: number;
  shortTrades: number;
  format: string;
  confidence?: number; // AI detection confidence percentage
  totalPnL?: number; // Total P&L of imported trades
  winRate?: number; // Win rate percentage
  originalRows?: number; // Original number of rows processed
  brokerDetected?: string; // Detected broker/platform format
  errorMessage?: string; // Error message if import failed
}

// Universal CSV Import Component supporting all formats with AI-powered broker detection
const UniversalCsvImport = ({ accounts }: { accounts: Account[] }) => {
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [csvFormat, setCsvFormat] = useState<string>('unknown');
  const [isUploading, setIsUploading] = useState(false);
  const [previewData, setPreviewData] = useState<any[]>([]);
  const [totalRowCount, setTotalRowCount] = useState<number>(0); // Track total rows
  const [importStats, setImportStats] = useState<ImportStats | null>(null);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const queryClient = useQueryClient();

  // Convert contract symbols to standard format - CRITICAL FIX for MESU5 detection
  const convertContractToSymbol = (contract: string): string => {
    if (!contract) return 'UNKNOWN';
    
    // Futures contract mapping - IMPORTANT: MES must come before ES to avoid wrong matching
    if (contract.startsWith('MES')) return 'MES';   // Micro E-mini S&P 500 - KEEP AS MES NOT ES!
    if (contract.startsWith('MNQ')) return 'MNQ';   // Micro E-mini NASDAQ 100
    if (contract.startsWith('ESU') || contract.startsWith('ES')) return 'ESU';   // E-mini S&P 500
    if (contract.startsWith('NQU') || contract.startsWith('NQ')) return 'NQ';    // E-mini NASDAQ 100
    if (contract.startsWith('YM')) return 'YM';    // E-mini Dow Jones
    if (contract.startsWith('RTY')) return 'RTY';  // E-mini Russell 2000
    if (contract.startsWith('GC')) return 'GC';    // Gold Futures
    if (contract.startsWith('CL')) return 'CL';    // Crude Oil Futures
    if (contract.startsWith('6E')) return 'EUR';   // Euro Futures
    if (contract.startsWith('6B')) return 'GBP';   // British Pound Futures
    
    // Return first 2-3 characters as fallback
    return contract.substring(0, Math.min(3, contract.length));
  };

  // Enhanced format detection for all CSV types
  const detectCsvFormat = (headers: string[]): string => {
    console.log('🔍 Detecting format for headers:', headers);
    
    // Standard Trading Platform Export (like your Excel file)
    if (headers.includes('Account') && 
        headers.includes('Date/Time') && 
        headers.includes('Symbol') && 
        headers.includes('Side') && 
        headers.includes('Quantity') && 
        headers.includes('Price') && 
        (headers.includes('Gross P/L') || headers.includes('Net P/L'))) {
      return 'standard-export';
    }
    
    // Position History CSV detection (most specific first)
    if (headers.includes('Position ID') && 
        headers.includes('Bought Timestamp') && 
        headers.includes('Sold Timestamp') &&
        (headers.includes('Paired Qty') || headers.includes('Buy Price'))) {
      return 'position-history';
    }
    
    // Performance CSV detection  
    if ((headers.includes('buyFillId') || headers.includes('Buy Fill ID')) && 
        (headers.includes('sellFillId') || headers.includes('Sell Fill ID')) && 
        (headers.includes('boughtTimestamp') || headers.includes('soldTimestamp') || 
         headers.includes('buyPrice') || headers.includes('sellPrice'))) {
      return 'performance';
    }
    
    // Orders CSV detection
    if (headers.includes('Order ID') && 
        (headers.includes('Fill Time') || headers.includes('Timestamp')) && 
        (headers.includes('B/S') || headers.includes('Side')) &&
        (headers.includes('Avg Fill Price') || headers.includes('Price'))) {
      return 'orders';
    }
    
    // Fills/Trades CSV detection
    if (headers.includes('Fill ID') && 
        headers.includes('Order ID') && 
        headers.includes('Timestamp') &&
        (headers.includes('B/S') || headers.includes('Side')) &&
        headers.includes('Price')) {
      return 'fills';
    }
    
    return 'unknown';
  };

  // Parse CSV text into structured data
  const parseCSV = (text: string) => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) return { headers: [], data: [] };
    
    // Parse headers (handle quotes and various delimiters)
    const firstLine = lines[0];
    const delimiter = firstLine.includes('\t') ? '\t' : ',';
    const headers = firstLine.split(delimiter).map(h => h.trim().replace(/^"|"$/g, ''));
    
    // Parse data rows
    const data = [];
    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(delimiter).map(v => v.trim().replace(/^"|"$/g, ''));
      const row: any = {};
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });
      
      // Skip empty rows
      if (Object.values(row).some(v => v !== '')) {
        data.push(row);
      }
    }
    
    return { headers, data };
  };

  // Enhanced Excel parsing with comprehensive debugging and better error handling
  const parseExcel = async (file: File): Promise<{ headers: string[], data: any[] }> => {
    console.log('📊 Starting Excel parse for file:', file.name, 'Size:', file.size, 'bytes');
    
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const arrayData = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(arrayData, { 
            type: 'array', 
            cellDates: true, 
            cellNF: false, 
            cellText: false,
            raw: false // This helps with number parsing
          });
          
          console.log('📊 Excel workbook loaded successfully');
          console.log('📊 Available sheets:', workbook.SheetNames);
          
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          
          console.log('📊 Processing sheet:', firstSheetName);
          
          // Get sheet range for debugging
          const range = XLSX.utils.decode_range(worksheet['!ref'] || 'A1');
          console.log('📊 Sheet range:', worksheet['!ref'], 'Rows:', range.e.r + 1, 'Cols:', range.e.c + 1);
          
          // Convert to JSON with header row as keys, preserving empty cells
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
            header: 1, 
            defval: '', 
            raw: false, // Parse numbers properly
            dateNF: 'yyyy-mm-dd hh:mm:ss' // Standardize date format
          });
          
          console.log('📊 Raw JSON data extracted, total rows:', jsonData.length);
          
          if (jsonData.length === 0) {
            reject(new Error('Excel file appears to be empty'));
            return;
          }
          
          // First row contains headers
          const headers = (jsonData[0] as string[]).map(h => String(h).trim());
          console.log('📊 Headers extracted:', headers);
          console.log('📊 Number of columns:', headers.length);
          
          // Rest are data rows - skip empty rows
          const dataRows = (jsonData.slice(1) as any[]).filter((row: any) => {
            // Check if row has any non-empty values
            return Array.isArray(row) && row.some(cell => cell !== null && cell !== undefined && String(cell).trim() !== '');
          });
          
          console.log('📊 Total rows after header:', jsonData.length - 1);
          console.log('📊 Non-empty data rows:', dataRows.length);
          
          // Convert rows to objects using headers as keys
          const processedData = dataRows.map((row: any, rowIndex: number) => {
            const obj: any = {};
            headers.forEach((header, colIndex) => {
              let cellValue = row[colIndex];
              
              // Handle various cell value types
              if (cellValue === null || cellValue === undefined) {
                cellValue = '';
              } else if (typeof cellValue === 'number') {
                // Keep numbers as numbers for better parsing
                cellValue = cellValue;
              } else {
                // Convert to string and trim
                cellValue = String(cellValue).trim();
              }
              
              obj[header] = cellValue;
            });
            
            // Debug first few rows
            if (rowIndex < 3) {
              console.log(`📊 Row ${rowIndex + 1} sample:`, {
                Account: obj['Account'],
                Symbol: obj['Symbol'],
                Side: obj['Side'],
                Quantity: obj['Quantity'],
                Price: obj['Price'],
                'Net P/L': obj['Net P/L']
              });
            }
            
            return obj;
          });
          
          console.log('📊 Successfully processed', processedData.length, 'data rows from Excel');
          console.log('📊 Final sample (first row):', processedData[0]);
          
          resolve({ headers, data: processedData });
        } catch (error) {
          console.error('📊 Excel parsing error:', error);
          reject(error);
        }
      };
      
      reader.onerror = () => reject(new Error('Failed to read Excel file'));
      reader.readAsArrayBuffer(file);
    });
  };

  // Find account by name or use first available account as fallback
  const findAccountByName = (accountName: string): any => {
    // First try exact match
    let account = accounts.find(acc => acc.name === accountName);
    
    // Then try partial match
    if (!account) {
      account = accounts.find(acc => acc.name.includes(accountName) || accountName.includes(acc.name));
    }
    
    // Finally, if no match and we have accounts, use the first available account
    if (!account && accounts.length > 0) {
      console.warn(`Account "${accountName}" not found. Using first available account: ${accounts[0].name}`);
      account = accounts[0];
    }
    
    if (!account) {
      throw new Error(`No accounts available. Please create an account first.`);
    }
    
    return account;
  };

  // Map Position History row to trade format
  const mapPositionHistoryRow = (row: any): any => {
    console.log('🔍 POSITION HISTORY: Mapping row:', row);
    
    const boughtTime = new Date(row['Bought Timestamp']);
    const soldTime = new Date(row['Sold Timestamp']);
    const isShort = soldTime < boughtTime;
    
    const account = findAccountByName(row['Account']);
    const buyPrice = parseFloat(row['Buy Price']);
    const sellPrice = parseFloat(row['Sell Price']);
    const pnl = parseFloat(row['P/L']);
    const quantity = parseInt(row['Paired Qty']);
    
    const mappedTrade = {
      accountId: account.id,
      symbol: convertContractToSymbol(row['Contract']),
      side: isShort ? 'sell' : 'buy',
      quantity: quantity || 1,
      fillTime: isShort ? row['Sold Timestamp'] : row['Bought Timestamp'],
      exitTime: isShort ? row['Bought Timestamp'] : row['Sold Timestamp'],
      entryPrice: isShort ? sellPrice : buyPrice,
      exitPrice: isShort ? buyPrice : sellPrice,
      pnl: pnl || 0,
      status: 'closed',
      date: row['Trade Date'] || new Date().toISOString().split('T')[0],
      orderId: `POS-${row['Position ID']}`,
      notes: `Position History Import - ${isShort ? 'Short' : 'Long'} Trade`,
      // Add required fields that might be missing
      initialStopLoss: null,
      finalStopLoss: null,
      initialTakeProfit: null,
      finalTakeProfit: null,
      tradeImage: null,
      tradingViewLink: null
    };

    console.log('🔍 POSITION HISTORY: Mapped trade:', {
      fillTime: mappedTrade.fillTime,
      exitTime: mappedTrade.exitTime,
      side: mappedTrade.side
    });

    return mappedTrade;
  };

  // Map Performance CSV row to trade format
  const mapPerformanceRow = (row: any): any => {
    console.log('🔍 PERFORMANCE: Mapping row:', row);
    
    const account = findAccountByName(row['Account'] || 'Default');
    const buyPrice = parseFloat(row['buyPrice'] || row['Buy Price']);
    const sellPrice = parseFloat(row['sellPrice'] || row['Sell Price']);
    const pnl = parseFloat(row['pnl'] || row['P/L']);
    const quantity = parseInt(row['qty'] || row['Quantity'] || 1);
    
    const mappedTrade = {
      accountId: account.id,
      symbol: convertContractToSymbol(row['symbol'] || row['Contract']),
      side: 'buy', // Performance CSV typically shows completed round trips
      quantity: quantity,
      fillTime: row['boughtTimestamp'] || row['Bought Timestamp'],
      exitTime: row['soldTimestamp'] || row['Sold Timestamp'],
      entryPrice: buyPrice,
      exitPrice: sellPrice,
      pnl: pnl,
      status: 'closed',
      date: row['date'] || row['Date'] || new Date().toISOString().split('T')[0],
      orderId: `PERF-${row['buyFillId'] || Date.now()}`,
      notes: 'Performance CSV Import',
      // Performance CSV has no SL/TP data - add required fields as null
      initialStopLoss: null,
      finalStopLoss: null,
      initialTakeProfit: null,
      finalTakeProfit: null,
      tradeImage: null,
      tradingViewLink: null
    };

    console.log('🔍 PERFORMANCE: Mapped trade:', {
      fillTime: mappedTrade.fillTime,
      exitTime: mappedTrade.exitTime
    });

    return mappedTrade;
  };

  // Map Standard Export row to trade format (Excel/CSV from trading platforms)
  const mapStandardExportRow = (row: any): any => {
    console.log('🔍 STANDARD EXPORT: Processing row:', row);
    
    // Check if this row has essential data - be more flexible with validation
    const symbol = row['Symbol'];
    const side = row['Side'];
    const quantity = row['Quantity'];
    const price = row['Price'];
    
    // FIXED: Only reject rows with truly missing data, not zero values
    if (!symbol || !side || quantity === undefined || quantity === null || price === undefined || price === null) {
      console.log('🔍 STANDARD EXPORT: Skipping row - missing essential data:', {
        symbol: symbol,
        side: side,
        quantity: quantity,
        price: price
      });
      return null;
    }
    
    // Convert quantity and price to numbers
    const numQuantity = Math.abs(parseFloat(quantity) || 0);
    const numPrice = parseFloat(price) || 0;
    
    // FIXED: Don't reject zero values - these are valid trade conditions
    // Zero quantity might indicate a cancelled order or adjustment
    // Zero price might indicate a bonus allocation or adjustment
    console.log('🔍 STANDARD EXPORT: Processing valid row:', {
      symbol,
      side,
      numQuantity,
      numPrice
    });
    
    const account = findAccountByName(row['Account'] || 'Default');
    const grossPnL = parseFloat(row['Gross P/L'] || 0);
    const netPnL = parseFloat(row['Net P/L'] || grossPnL);
    const sideText = (side || '').toLowerCase();
    const tradeSide = sideText.includes('sell') ? 'sell' : 'buy';
    
    // Parse date/time
    const dateTime = row['Date/Time'];
    const fillTime = dateTime ? new Date(dateTime) : new Date();
    
    // For standard exports, we typically don't have exit data, so we treat each row as a position
    const mappedTrade = {
      accountId: account.id,
      symbol: convertContractToSymbol(symbol),
      side: tradeSide,
      quantity: numQuantity,
      fillTime: fillTime.toISOString(),
      exitTime: fillTime.toISOString(), // Same as fill time for individual positions
      entryPrice: numPrice,
      exitPrice: numPrice, // Same as entry for individual positions
      pnl: netPnL,
      status: 'closed',
      date: fillTime.toISOString().split('T')[0],
      orderId: row['Order ID'] || row['Trade ID'] || `STD-${Date.now()}-${Math.random()}`,
      notes: `Standard Export Import - ${row['Description'] || 'Trade'}`,
      // Standard exports typically don't have SL/TP data
      initialStopLoss: null,
      finalStopLoss: null,
      initialTakeProfit: null,
      finalTakeProfit: null,
      tradeImage: null,
      tradingViewLink: null
    };

    console.log('🔍 STANDARD EXPORT: Successfully mapped trade:', {
      symbol: mappedTrade.symbol,
      side: mappedTrade.side,
      quantity: mappedTrade.quantity,
      price: mappedTrade.entryPrice,
      pnl: mappedTrade.pnl
    });

    return mappedTrade;
  };

  // Advanced Orders CSV mapping with position tracking and SL/TP detection
  const mapOrdersRows = (rows: any[]): any[] => {
    console.log('🔍 ADVANCED ORDERS: Processing', rows.length, 'order rows with position tracking and SL/TP detection');
    
    const trades: any[] = [];
    
    // Helper function to group orders
    const groupBy = (array: any[], keyFn: (item: any) => string) => {
      const groups: { [key: string]: any[] } = {};
      array.forEach(item => {
        const key = keyFn(item);
        if (!groups[key]) groups[key] = [];
        groups[key].push(item);
      });
      return groups;
    };
    
    // Helper function to calculate weighted average
    const calculateWeightedAverage = (entries: any[], field: string) => {
      const totalQty = entries.reduce((sum, entry) => sum + entry.qty, 0);
      const weightedSum = entries.reduce((sum, entry) => sum + (entry[field] * entry.qty), 0);
      return weightedSum / totalQty;
    };
    
    // Helper function to calculate duration
    const calculateDuration = (startTime: string, endTime: string): string => {
      const start = new Date(startTime);
      const end = new Date(endTime);
      const durationMs = end.getTime() - start.getTime();
      const minutes = Math.floor(durationMs / (60 * 1000));
      
      if (minutes < 60) return `${minutes}m`;
      const hours = Math.floor(minutes / 60);
      const remainingMinutes = minutes % 60;
      return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}m` : `${hours}h`;
    };
    
    // Group ALL orders (filled + cancelled) by symbol + account + trading day for SL/TP analysis
    const allOrderGroups = groupBy(rows, (order) => {
      const symbol = convertContractToSymbol(order['Contract']);
      const account = order['Account'];
      const date = order['Date'] || order['Fill Time']?.split(' ')[0] || '';
      return `${symbol}-${account}-${date}`;
    });
    
    // Filter filled orders for position tracking
    const orderGroups = groupBy(rows.filter(row => row.Status === 'Filled'), (order) => {
      const symbol = convertContractToSymbol(order['Contract']);
      const account = order['Account'];
      const date = order['Date'] || order['Fill Time']?.split(' ')[0] || '';
      return `${symbol}-${account}-${date}`;
    });
    
    console.log('🔍 ADVANCED ORDERS: Created', Object.keys(orderGroups).length, 'order groups');
    
    // Process each group with position tracking
    Object.entries(orderGroups).forEach(([groupKey, orderGroup]) => {
      console.log('🔍 ADVANCED ORDERS: Processing group:', groupKey, 'with', orderGroup.length, 'orders');
      
      // Sort orders chronologically
      orderGroup.sort((a, b) => {
        const timeA = new Date(a['Fill Time'] || a['Timestamp']).getTime();
        const timeB = new Date(b['Fill Time'] || b['Timestamp']).getTime();
        return timeA - timeB;
      });
      
      // Position tracking variables
      let position = 0; // Current net position
      let positionEntries: any[] = []; // Orders that built current position
      let tradeCounter = 1;
      
      // Get ALL orders for this group (including cancelled) for SL/TP detection
      const allOrdersInGroup = allOrderGroups[groupKey] || [];
      
      // Detect Stop Loss and Take Profit orders from cancelled orders - ENHANCED SL/TP DETECTION
      const detectSLTPOrders = () => {
        const cancelledOrders = allOrdersInGroup.filter(order => 
          order.Status === 'Cancelled' || order.Status === 'Canceled'
        );
        
        console.log(`🔍 SL/TP DETECTION: Found ${cancelledOrders.length} cancelled orders in group`);
        
        const stopLossOrders = cancelledOrders.filter(order => {
          const orderType = (order['Order Type'] || order['Type'] || '').toLowerCase();
          const hasStopPrice = order['Stop Price'] && order['Stop Price'].trim() !== '';
          const isStopOrder = orderType.includes('stop');
          
          console.log(`🔍 Order: ${order['Order ID']} - Type: ${orderType}, HasStopPrice: ${hasStopPrice}, IsStopOrder: ${isStopOrder}`);
          
          return isStopOrder || hasStopPrice;
        });
        
        const takeProfitOrders = cancelledOrders.filter(order => {
          const orderType = (order['Order Type'] || order['Type'] || '').toLowerCase();
          const hasLimitPrice = order['Limit Price'] && order['Limit Price'].trim() !== '';
          const isLimitOrder = orderType.includes('limit');
          
          return isLimitOrder && hasLimitPrice && !stopLossOrders.includes(order);
        });
        
        console.log(`🔍 SL/TP RESULT: ${stopLossOrders.length} stop losses, ${takeProfitOrders.length} take profits`);
        
        return { stopLossOrders, takeProfitOrders };
      };
      
      const { stopLossOrders, takeProfitOrders } = detectSLTPOrders();
      
      console.log(`🔍 SL/TP DETECTION: Found ${stopLossOrders.length} stop loss orders and ${takeProfitOrders.length} take profit orders for group ${groupKey}`);
      
      if (stopLossOrders.length > 0) {
        console.log('🔍 Stop Loss Orders:', stopLossOrders.map(o => ({ price: o['Avg Fill Price'] || o['Price'], type: o['Order Type'] || o['Type'], status: o.Status })));
      }
      if (takeProfitOrders.length > 0) {
        console.log('🔍 Take Profit Orders:', takeProfitOrders.map(o => ({ price: o['Avg Fill Price'] || o['Price'], type: o['Order Type'] || o['Type'], status: o.Status })));
      }
      
      // Function to get initial and final SL/TP levels - ENHANCED DETECTION
      const getSLTPLevels = (isLong: boolean) => {
        // Get chronologically ordered SL orders using Stop Price instead of Avg Fill Price
        const chronoStopLoss = stopLossOrders
          .filter(order => order['Stop Price'] || order['Limit Price'] || order['Avg Fill Price'] || order['Price'])
          .map(order => ({
            ...order,
            effectivePrice: parseFloat(order['Stop Price'] || order['Limit Price'] || order['Avg Fill Price'] || order['Price'] || '0')
          }))
          .filter(order => order.effectivePrice > 0)
          .sort((a, b) => {
            const timeA = new Date(a['Fill Time'] || a['Timestamp'] || 0).getTime();
            const timeB = new Date(b['Fill Time'] || b['Timestamp'] || 0).getTime();
            return timeA - timeB;
          });
          
        console.log(`🔍 SL Analysis: Found ${chronoStopLoss.length} valid stop loss orders with prices`);
        chronoStopLoss.forEach((order, i) => {
          console.log(`  ${i+1}. Price: ${order.effectivePrice}, Time: ${order['Fill Time'] || order['Timestamp']}`);
        });
          
        // Get chronologically ordered TP orders  
        const chronoTakeProfit = takeProfitOrders
          .filter(order => order['Avg Fill Price'] || order['Price'])
          .sort((a, b) => {
            const timeA = new Date(a['Fill Time'] || a['Timestamp'] || 0).getTime();
            const timeB = new Date(b['Fill Time'] || b['Timestamp'] || 0).getTime();
            return timeA - timeB;
          });
        
        return {
          initialStopLoss: chronoStopLoss.length > 0 ? 
            parseFloat(chronoStopLoss[0]['Avg Fill Price'] || chronoStopLoss[0]['Price']) : null,
          finalStopLoss: chronoStopLoss.length > 0 ? 
            parseFloat(chronoStopLoss[chronoStopLoss.length - 1]['Avg Fill Price'] || chronoStopLoss[chronoStopLoss.length - 1]['Price']) : null,
          initialTakeProfit: chronoTakeProfit.length > 0 ? 
            parseFloat(chronoTakeProfit[0]['Avg Fill Price'] || chronoTakeProfit[0]['Price']) : null,
          finalTakeProfit: chronoTakeProfit.length > 0 ? 
            parseFloat(chronoTakeProfit[chronoTakeProfit.length - 1]['Avg Fill Price'] || chronoTakeProfit[chronoTakeProfit.length - 1]['Price']) : null
        };
      };
      
      orderGroup.forEach((order, index) => {
        const side = order['B/S']?.toLowerCase();
        const quantity = parseInt(order['Filled Qty'] || order['Quantity'] || 0);
        const price = parseFloat(order['Avg Fill Price'] || order['Price'] || 0);
        const fillTime = order['Fill Time'] || order['Timestamp'];
        
        if (!quantity || !price || !fillTime) {
          console.log('🔍 ADVANCED ORDERS: Skipping invalid order:', order);
          return;
        }
        
        // Calculate position change
        const orderQty = (side === 'buy' || side === 'b') ? quantity : -quantity;
        const newPosition = position + orderQty;
        
        console.log(`🔍 ADVANCED ORDERS: Order ${index + 1}: ${side.toUpperCase()} ${quantity} @ ${price}`);
        console.log(`🔍 ADVANCED ORDERS: Position: ${position} → ${newPosition}`);
        
        // CASE 1: Opening new position (from flat)
        if (position === 0 && newPosition !== 0) {
          console.log('🔍 ADVANCED ORDERS: Opening new position');
          positionEntries = [{
            fillTime,
            price,
            qty: Math.abs(orderQty),
            side: newPosition > 0 ? 'buy' : 'sell',
            order
          }];
        }
        
        // CASE 2: Adding to existing position (scaling in)
        else if (position !== 0 && Math.sign(position) === Math.sign(newPosition) && Math.abs(newPosition) > Math.abs(position)) {
          console.log('🔍 ADVANCED ORDERS: Adding to position (scaling in)');
          positionEntries.push({
            fillTime,
            price,
            qty: Math.abs(orderQty),
            side: newPosition > 0 ? 'buy' : 'sell',
            order
          });
        }
        
        // CASE 3: Partially closing position
        else if (position !== 0 && Math.sign(position) === Math.sign(newPosition) && Math.abs(newPosition) < Math.abs(position)) {
          console.log('🔍 ADVANCED ORDERS: Partially closing position');
          
          const closedQuantity = Math.abs(orderQty);
          
          // Calculate weighted entry values for the portion being closed
          const weightedEntryPrice = calculateWeightedAverage(positionEntries, 'price');
          const earliestEntryTime = positionEntries[0].fillTime; // Use earliest entry for duration
          
          // Get SL/TP levels for this trade
          const isLong = position > 0;
          const slTPLevels = getSLTPLevels(isLong);
          
          const trade = {
            accountId: findAccountByName(order['Account']).id,
            symbol: convertContractToSymbol(order['Contract']),
            side: position > 0 ? 'buy' : 'sell',
            quantity: closedQuantity,
            fillTime: earliestEntryTime,
            exitTime: fillTime,
            entryPrice: weightedEntryPrice,
            exitPrice: price,
            pnl: 0, // Will calculate below
            status: 'closed',
            date: order['Date'] || fillTime.split(' ')[0],
            orderId: `ADV-${groupKey}-${tradeCounter++}`,
            notes: `Advanced Orders Import - Partial Close (${calculateDuration(earliestEntryTime, fillTime)})`,
            // Apply detected SL/TP levels
            initialStopLoss: slTPLevels.initialStopLoss,
            finalStopLoss: slTPLevels.finalStopLoss,
            initialTakeProfit: slTPLevels.initialTakeProfit,
            finalTakeProfit: slTPLevels.finalTakeProfit,
            tradeImage: null,
            tradingViewLink: null
          };
          
          // Calculate P&L - CRITICAL FIX for accurate P&L calculation
          const priceDiff = trade.exitPrice - trade.entryPrice;
          const multiplier = getContractMultiplier(trade.symbol);
          if (trade.side === 'buy') {
            // Long position: profit = (exit - entry) * quantity * multiplier
            trade.pnl = priceDiff * trade.quantity * multiplier;
          } else {
            // Short position: profit = (entry - exit) * quantity * multiplier
            trade.pnl = -priceDiff * trade.quantity * multiplier;
          }
          
          trades.push(trade);
          console.log('🔍 ADVANCED ORDERS: Created partial close trade:', calculateDuration(earliestEntryTime, fillTime));
          
          // Adjust positionEntries to reflect remaining position (FIFO basis)
          let qtyToRemove = closedQuantity;
          positionEntries = positionEntries.filter(entry => {
            if (qtyToRemove <= 0) return true;
            
            if (entry.qty <= qtyToRemove) {
              qtyToRemove -= entry.qty;
              return false; // Remove this entry completely
            } else {
              entry.qty -= qtyToRemove;
              qtyToRemove = 0;
              return true; // Keep partial entry
            }
          });
        }
        
        // CASE 4: Completely closing position
        else if (position !== 0 && newPosition === 0) {
          console.log('🔍 ADVANCED ORDERS: Completely closing position');
          
          // Calculate weighted entry values
          const weightedEntryPrice = calculateWeightedAverage(positionEntries, 'price');
          const earliestEntryTime = positionEntries[0].fillTime;
          
          // Get SL/TP levels for this trade
          const isLong = position > 0;
          const slTPLevels = getSLTPLevels(isLong);
          
          const trade = {
            accountId: findAccountByName(order['Account']).id,
            symbol: convertContractToSymbol(order['Contract']),
            side: position > 0 ? 'buy' : 'sell',
            quantity: Math.abs(position),
            fillTime: earliestEntryTime,
            exitTime: fillTime,
            entryPrice: weightedEntryPrice,
            exitPrice: price,
            pnl: 0, // Will calculate below
            status: 'closed',
            date: order['Date'] || fillTime.split(' ')[0],
            orderId: `ADV-${groupKey}-${tradeCounter++}`,
            notes: `Advanced Orders Import - Complete Close (${calculateDuration(earliestEntryTime, fillTime)})`,
            // Apply detected SL/TP levels
            initialStopLoss: slTPLevels.initialStopLoss,
            finalStopLoss: slTPLevels.finalStopLoss,
            initialTakeProfit: slTPLevels.initialTakeProfit,
            finalTakeProfit: slTPLevels.finalTakeProfit,
            tradeImage: null,
            tradingViewLink: null
          };
          
          // Calculate P&L - CRITICAL FIX for accurate P&L calculation
          const priceDiff = trade.exitPrice - trade.entryPrice;
          const multiplier = getContractMultiplier(trade.symbol);
          if (trade.side === 'buy') {
            // Long position: profit = (exit - entry) * quantity * multiplier
            trade.pnl = priceDiff * trade.quantity * multiplier;
          } else {
            // Short position: profit = (entry - exit) * quantity * multiplier
            trade.pnl = -priceDiff * trade.quantity * multiplier;
          }
          
          trades.push(trade);
          console.log('🔍 ADVANCED ORDERS: Created complete trade:', calculateDuration(earliestEntryTime, fillTime));
          
          // Reset position tracking
          positionEntries = [];
        }
        
        // CASE 5: Position reversal (close current + open opposite)
        else if (position !== 0 && newPosition !== 0 && Math.sign(position) !== Math.sign(newPosition)) {
          console.log('🔍 ADVANCED ORDERS: Position reversal detected');
          
          // First, close the existing position
          const weightedEntryPrice = calculateWeightedAverage(positionEntries, 'price');
          const earliestEntryTime = positionEntries[0].fillTime;
          
          // Get SL/TP levels for this trade
          const isLong = position > 0;
          const slTPLevels = getSLTPLevels(isLong);
          
          const closeTrade = {
            accountId: findAccountByName(order['Account']).id,
            symbol: convertContractToSymbol(order['Contract']),
            side: position > 0 ? 'buy' : 'sell',
            quantity: Math.abs(position),
            fillTime: earliestEntryTime,
            exitTime: fillTime,
            entryPrice: weightedEntryPrice,
            exitPrice: price,
            pnl: 0, // Will calculate below
            status: 'closed',
            date: order['Date'] || fillTime.split(' ')[0],
            orderId: `ADV-${groupKey}-${tradeCounter++}`,
            notes: `Advanced Orders Import - Reversal Close (${calculateDuration(earliestEntryTime, fillTime)})`,
            // Apply detected SL/TP levels
            initialStopLoss: slTPLevels.initialStopLoss,
            finalStopLoss: slTPLevels.finalStopLoss,
            initialTakeProfit: slTPLevels.initialTakeProfit,
            finalTakeProfit: slTPLevels.finalTakeProfit,
            tradeImage: null,
            tradingViewLink: null
          };
          
          // Calculate P&L for close trade - CRITICAL FIX
          const priceDiff = closeTrade.exitPrice - closeTrade.entryPrice;
          const multiplier = getContractMultiplier(closeTrade.symbol);
          if (closeTrade.side === 'buy') {
            // Long position: profit = (exit - entry) * quantity * multiplier
            closeTrade.pnl = priceDiff * closeTrade.quantity * multiplier;
          } else {
            // Short position: profit = (entry - exit) * quantity * multiplier
            closeTrade.pnl = -priceDiff * closeTrade.quantity * multiplier;
          }
          
          trades.push(closeTrade);
          console.log('🔍 ADVANCED ORDERS: Created reversal close trade:', calculateDuration(earliestEntryTime, fillTime));
          
          // Then, start new position in opposite direction
          const newPositionQty = Math.abs(newPosition);
          positionEntries = [{
            fillTime,
            price,
            qty: newPositionQty,
            side: newPosition > 0 ? 'buy' : 'sell',
            order
          }];
          
          console.log('🔍 ADVANCED ORDERS: Started new position after reversal');
        }
        
        // Update position
        position = newPosition;
        console.log(`🔍 ADVANCED ORDERS: Updated position to: ${position}`);
      });
      
      // Handle any remaining open position
      if (Math.abs(position) > 0) {
        console.log('🔍 ADVANCED ORDERS: Position remains open:', position);
      }
    });
    
    console.log('🔍 ADVANCED ORDERS: Created', trades.length, 'trades with durations');
    
    // Log sample trade with duration
    if (trades.length > 0) {
      console.log('🔍 ADVANCED ORDERS: Sample trade with duration:', {
        symbol: trades[0].symbol,
        side: trades[0].side,
        fillTime: trades[0].fillTime,
        exitTime: trades[0].exitTime,
        pnl: trades[0].pnl
      });
    }
    
    return trades;
  };

  // Map Fills CSV - similar to Orders but with Fill IDs
  const mapFillsRows = (rows: any[]): any[] => {
    console.log('🔍 FILLS: Processing', rows.length, 'fill rows');
    
    const trades = [];
    const fillGroups = new Map();
    
    // Group fills by Order ID to match entry/exit
    rows.forEach(row => {
      const orderId = row['Order ID'];
      if (!fillGroups.has(orderId)) {
        fillGroups.set(orderId, []);
      }
      fillGroups.get(orderId).push(row);
    });
    
    // Process each order's fills
    for (const [orderId, fills] of Array.from(fillGroups.entries())) {
      if (fills.length >= 2) {
        // Sort by timestamp to determine entry/exit
        fills.sort((a: any, b: any) => new Date(a.Timestamp).getTime() - new Date(b.Timestamp).getTime());
        
        const entryFill = fills[0];
        const exitFill = fills[fills.length - 1];
        
        const account = findAccountByName(entryFill['Account']);
        
        const trade = {
          accountId: account.id,
          symbol: convertContractToSymbol(entryFill['Contract']),
          side: entryFill['B/S'].toLowerCase() === 'buy' ? 'buy' : 'sell',
          quantity: parseInt(entryFill['Quantity']),
          fillTime: entryFill['Timestamp'],
          exitTime: exitFill['Timestamp'],
          entryPrice: parseFloat(entryFill['Price']),
          exitPrice: parseFloat(exitFill['Price']),
          pnl: 0, // Calculate later
          status: 'closed',
          date: entryFill['Date'] || entryFill['Timestamp'].split(' ')[0],
          orderId: `FILL-${orderId}`,
          notes: 'Fills CSV Import'
        };
        
        // Calculate P&L - CRITICAL FIX for accurate P&L calculation
        const priceDiff = trade.exitPrice - trade.entryPrice;
        const multiplier = getContractMultiplier(trade.symbol);
        if (trade.side === 'buy') {
          // Long position: profit = (exit - entry) * quantity * multiplier
          trade.pnl = priceDiff * trade.quantity * multiplier;
        } else {
          // Short position: profit = (entry - exit) * quantity * multiplier
          trade.pnl = -priceDiff * trade.quantity * multiplier;
        }
        
        trades.push(trade);
      }
    }
    
    console.log('🔍 FILLS: Created', trades.length, 'matched trades');
    return trades;
  };

  // Main mapping function - routes to appropriate mapper
  const mapRowsToTrades = (rows: any[], format: string): any[] => {
    console.log(`🔍 MAPPING: Processing ${rows.length} rows with format: ${format}`);
    
    let result: any[] = [];
    
    switch (format) {
      case 'standard-export':
        result = rows.map(mapStandardExportRow).filter(trade => trade !== null);
        break;
      case 'position-history':
        result = rows.map(mapPositionHistoryRow);
        break;
      case 'performance':
        result = rows.map(mapPerformanceRow);
        break;
      case 'orders':
        result = mapOrdersRows(rows);
        break;
      case 'fills':
        result = mapFillsRows(rows);
        break;
      default:
        throw new Error(`Unsupported format: ${format}`);
    }
    
    console.log(`🔍 MAPPING: Generated ${result.length} trades from ${rows.length} rows`);
    return result;
  };



  // Handle file selection and preview
  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setCsvFile(file);
    setImportStats(null);
    
    try {
      let headers: string[] = [];
      let data: any[] = [];
      
      // Check file type and parse accordingly
      const fileExtension = file.name.toLowerCase().split('.').pop();
      
      if (fileExtension === 'xlsx' || fileExtension === 'xls') {
        console.log('📊 Processing Excel file...');
        const excelData = await parseExcel(file);
        headers = excelData.headers;
        data = excelData.data;
      } else {
        console.log('📄 Processing CSV file...');
        const text = await file.text();
        const csvData = parseCSV(text);
        headers = csvData.headers;
        data = csvData.data;
      }
      
      setCsvHeaders(headers);
      const detectedFormat = detectCsvFormat(headers);
      setCsvFormat(detectedFormat);
      
      // Show preview
      setTotalRowCount(data.length);
      setPreviewData(data.slice(0, Math.min(10, data.length))); // Show up to 10 records
      
      console.log(`🔍 File type: ${fileExtension}`);
      console.log(`🔍 Detected format: ${detectedFormat}`);
      console.log(`🔍 Found ${data.length} data rows`);
      console.log(`🔍 Headers:`, headers);
      
    } catch (error) {
      console.error('Error parsing file:', error);
      console.error(`Error parsing file: ${(error as Error).message}`);
      setCsvFile(null);
      setPreviewData([]);
      setTotalRowCount(0); // Add this line
      setCsvFormat('unknown');
    }
  };

  // Enhanced AI-powered CSV upload supporting 37+ brokers
  const handleUpload = async () => {
    if (!csvFile || !selectedImportAccount) return;

    setIsUploading(true);
    
    try {
      // Read file content
      const fileContent = await csvFile.text();
      console.log("📄 Universal CSV Import - File content loaded:", { 
        fileName: csvFile.name, 
        contentLength: fileContent.length,
        accountId: selectedImportAccount,
        firstChars: fileContent.substring(0, 200)
      });

      // Send to AI-powered backend for broker detection and processing
      const response = await fetch('/api/trades/import-csv', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          accountId: parseInt(selectedImportAccount),
          csvData: fileContent,
          fileName: csvFile.name
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Network error' }));
        throw new Error(errorData.message || 'Failed to process CSV');
      }

      const result = await response.json();
      
      if (!result.success) {
        throw new Error(result.message || 'Import failed');
      }

      console.log('🎯 Universal CSV Import - AI detection result:', {
        detectedFormat: result.detectedFormat,
        confidence: result.confidence,
        recordsProcessed: result.recordsProcessed,
        recordsImported: result.recordsImported,
        totalPnL: result.totalPnL,
        winRate: result.winRate
      });
      
      // Show preview of imported trades  
      setPreviewData(result.importedTrades || []);
      
      // Set import statistics with AI detection results
      setImportStats({
        imported: result.recordsImported,
        errors: result.errors?.length || 0,
        longTrades: (result.importedTrades || []).filter((t: any) => t.side === 'buy').length,
        shortTrades: (result.importedTrades || []).filter((t: any) => t.side === 'sell').length,
        format: result.detectedFormat,
        confidence: result.confidence,
        totalPnL: result.totalPnL,
        winRate: result.winRate,
        originalRows: result.recordsProcessed,
        brokerDetected: result.detectedFormat
      });

      // Refresh trades list to show new imports
      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
      
      // Reset form
      setCsvFile(null);
      setPreviewData([]);
      setTotalRowCount(0);
      setCsvFormat('unknown');
      setCsvHeaders([]);
      
    } catch (error) {
      console.error('Universal CSV Import error:', error);
      setImportStats({
        imported: 0,
        errors: 1,
        longTrades: 0,
        shortTrades: 0,
        format: 'error',
        errorMessage: error instanceof Error ? error.message : 'Unknown error occurred'
      });
    } finally {
      setIsUploading(false);
    }
  };

  // Enhanced broker detection info with 37+ supported platforms
  const getFormatInfo = (format: string) => {
    const formatDetails = {
      // Traditional Brokers (12)
      'interactive-brokers': { icon: '🏦', name: 'Interactive Brokers', description: 'IBKR Flex Query exports and activity statements', features: ['✅ TWS Reports', '✅ Flex Queries', '✅ Activity Statements'] },
      'thinkorswim': { icon: '📈', name: 'ThinkorSwim (TD Ameritrade)', description: 'ToS account statements and trade history', features: ['✅ Account Statements', '✅ Order History', '✅ P&L Reports'] },
      'robinhood': { icon: '🤖', name: 'Robinhood', description: 'Robinhood trading reports and statements', features: ['✅ Order Reports', '✅ Dividend History', '✅ Account Activity'] },
      'etrade': { icon: '💼', name: 'E*TRADE', description: 'E*TRADE account downloads and trade confirmations', features: ['✅ Trade Confirmations', '✅ Account Downloads', '✅ Portfolio Reports'] },
      'schwab': { icon: '🏛️', name: 'Charles Schwab', description: 'Schwab StreetSmart reports and account exports', features: ['✅ StreetSmart Reports', '✅ Account Exports', '✅ Trade History'] },
      'fidelity': { icon: '🔷', name: 'Fidelity', description: 'Fidelity Active Trader Pro and account reports', features: ['✅ ATP Reports', '✅ Account History', '✅ Trade Confirmations'] },
      'webull': { icon: '🌐', name: 'Webull', description: 'Webull desktop and mobile trading reports', features: ['✅ Trading Reports', '✅ Account Statements', '✅ P&L History'] },
      'coinbase': { icon: '₿', name: 'Coinbase Pro', description: 'Coinbase trading history and portfolio reports', features: ['✅ Trading History', '✅ Portfolio Reports', '✅ Tax Documents'] },
      'kraken': { icon: '🐙', name: 'Kraken', description: 'Kraken trading history and ledger exports', features: ['✅ Trading History', '✅ Ledger Exports', '✅ Trade Reports'] },
      'binance': { icon: '🔶', name: 'Binance', description: 'Binance spot and futures trading history', features: ['✅ Spot Trading', '✅ Futures Trading', '✅ P&L Reports'] },
      'tastytrade': { icon: '🎯', name: 'Tastytrade', description: 'Tastytrade platform reports and trade history', features: ['✅ Trade History', '✅ P&L Reports', '✅ Account Activity'] },
      'alpaca': { icon: '🦙', name: 'Alpaca', description: 'Alpaca API trading data and portfolio reports', features: ['✅ API Data', '✅ Portfolio Reports', '✅ Trade History'] },

      // Trading Platforms (19)
      'metatrader4': { icon: '📊', name: 'MetaTrader 4', description: 'MT4 history exports and trade reports', features: ['✅ Account History', '✅ Trade Reports', '✅ Custom Periods'] },
      'metatrader5': { icon: '📈', name: 'MetaTrader 5', description: 'MT5 detailed history and position reports', features: ['✅ Position History', '✅ Deal History', '✅ Account Reports'] },
      'ninjatrader': { icon: '🥷', name: 'NinjaTrader', description: 'NinjaTrader 8 trade performance and execution reports', features: ['✅ Trade Performance', '✅ Execution Reports', '✅ Strategy Reports'] },
      'tradestation': { icon: '🚂', name: 'TradeStation', description: 'TradeStation portfolio and trade analysis reports', features: ['✅ Portfolio Reports', '✅ Trade Analysis', '✅ P&L Reports'] },
      'tradingview': { icon: '📺', name: 'TradingView', description: 'TradingView broker integration exports', features: ['✅ Broker Integration', '✅ Paper Trading', '✅ Strategy Reports'] },
      'ctrader': { icon: '⚡', name: 'cTrader', description: 'cTrader history and trade reports', features: ['✅ Trade History', '✅ Position Reports', '✅ Account Statistics'] },
      'jforex': { icon: '🏪', name: 'JForex', description: 'Dukascopy JForex platform reports', features: ['✅ Platform Reports', '✅ Trade History', '✅ Strategy Reports'] },
      'tws': { icon: '💹', name: 'TWS (Trader Workstation)', description: 'IBKR TWS activity reports and trade logs', features: ['✅ Activity Reports', '✅ Trade Logs', '✅ Portfolio Reports'] },
      'tos': { icon: '🎨', name: 'ThinkOrSwim Platform', description: 'ToS platform monitor and trade reports', features: ['✅ Monitor Reports', '✅ Trade Reports', '✅ Strategy Reports'] },
      'sterling': { icon: '💎', name: 'Sterling Trader Pro', description: 'Sterling professional trading platform reports', features: ['✅ Professional Reports', '✅ Trade Blotter', '✅ P&L Reports'] },
      'das': { icon: '⚖️', name: 'DAS Trader', description: 'DAS Trader Pro execution and trade reports', features: ['✅ Execution Reports', '✅ Trade Reports', '✅ Risk Reports'] },
      'speedtrader': { icon: '🏃', name: 'SpeedTrader', description: 'SpeedTrader platform trade and execution reports', features: ['✅ Trade Reports', '✅ Execution Reports', '✅ Account Reports'] },
      'lightspeed': { icon: '💨', name: 'Lightspeed', description: 'Lightspeed Trader platform reports', features: ['✅ Platform Reports', '✅ Trade History', '✅ P&L Analysis'] },
      'centerpoint': { icon: '🎯', name: 'CenterPoint Securities', description: 'CenterPoint trading platform reports', features: ['✅ Trading Reports', '✅ Account Activity', '✅ P&L Reports'] },
      'eris': { icon: '⚔️', name: 'Eris X', description: 'Eris Exchange trading reports', features: ['✅ Exchange Reports', '✅ Trade History', '✅ Settlement Reports'] },
      'volfix': { icon: '📊', name: 'Volfix', description: 'Volfix volume analysis platform exports', features: ['✅ Volume Analysis', '✅ Trade Reports', '✅ Market Data'] },
      'bookmap': { icon: '📚', name: 'Bookmap', description: 'Bookmap visualization platform trade data', features: ['✅ Visualization Data', '✅ Trade Reports', '✅ Market Analysis'] },
      'quantower': { icon: '🌊', name: 'Quantower', description: 'Quantower platform trade and analysis reports', features: ['✅ Trade Reports', '✅ Analysis Reports', '✅ Portfolio Data'] },
      'rithmic': { icon: '🎵', name: 'Rithmic', description: 'Rithmic trading platform data feeds', features: ['✅ Data Feeds', '✅ Trade Reports', '✅ Account Data'] },

      // Futures & Specialized (6)
      'tradovate': { icon: '🌾', name: 'Tradovate', description: 'Tradovate futures trading platform reports', features: ['✅ Futures Trading', '✅ Account Reports', '✅ P&L Analysis'] },
      'amp': { icon: '🔌', name: 'AMP Futures', description: 'AMP Global futures trading reports', features: ['✅ Futures Reports', '✅ Trade History', '✅ Account Activity'] },
      'advantage': { icon: '✨', name: 'Advantage Futures', description: 'Advantage Futures platform trade reports', features: ['✅ Platform Reports', '✅ Trade History', '✅ Account Data'] },
      'bybit': { icon: '🚀', name: 'Bybit', description: 'Bybit crypto derivatives trading history', features: ['✅ Derivatives Trading', '✅ Crypto History', '✅ P&L Reports'] },
      'bitmex': { icon: '⚡', name: 'BitMEX', description: 'BitMEX crypto derivatives and trading data', features: ['✅ Derivatives Data', '✅ Trading History', '✅ Account Reports'] },
      'alphaticks': { icon: '🎭', name: 'Alpha Ticks', description: 'Alpha Ticks professional trading data', features: ['✅ Professional Data', '✅ Trade Reports', '✅ Market Analysis'] },

      // Generic formats for fallback
      'standard-export': { icon: '📊', name: 'Standard Export', description: 'Standard trading platform export with account, time, symbol, and P&L data', features: ['✅ Excel & CSV Support', '✅ Account Info', '✅ Date/Time', '✅ Symbol & Side', '✅ Quantity & Price', '✅ P&L Data'] },
      'position-history': { icon: '🏛️', name: 'Position History', description: 'Complete trade pairs with entry/exit timestamps', features: ['✅ Entry & Exit Times', '✅ Long & Short Detection', '✅ Calculated P&L', '✅ Account Info'] },
      'performance': { icon: '📊', name: 'Performance', description: 'Trade performance data with P&L metrics', features: ['✅ Entry & Exit Times', '✅ Pre-calculated P&L', '✅ Fill IDs', '⚠️ May need account mapping'] },
      'orders': { icon: '📋', name: 'Orders', description: 'Individual order records (will match buy/sell pairs)', features: ['✅ Order matching', '✅ Fill times', '⚠️ Requires buy/sell pairing', '✅ Account info'] },
      'fills': { icon: '🔄', name: 'Fills/Trades', description: 'Individual fill records (will group by Order ID)', features: ['✅ Fill-level detail', '✅ Timestamps', '⚠️ Requires fill matching', '✅ Commission data'] },
      'unknown': { icon: '❓', name: 'Unknown Format', description: 'CSV format not recognized - AI will analyze and detect automatically', features: ['🤖 AI-Powered Detection', '📊 37+ Broker Support', '🔍 Smart Analysis'] }
    };
    
    return formatDetails[format as keyof typeof formatDetails] || formatDetails['unknown'];
  };

  const formatInfo = getFormatInfo(csvFormat);

  // Account selection state for CSV import
  const [selectedImportAccount, setSelectedImportAccount] = useState<string>("");


  return (
    <div className="space-y-6">
      {/* Account Selection for CSV Import */}
      <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/30">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Target className="w-6 h-6 text-blue-400" />
            <CardTitle className="text-blue-400">Account Selection</CardTitle>
          </div>
          <p className="text-gray-400">Choose which trading account to import your trades to</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-gray-300 font-medium">Select Trading Account</Label>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
                    console.log('🔄 Refreshing accounts list...');
                  }}
                  className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10 h-auto p-1"
                >
                  <RotateCcw className="w-4 h-4" />
                </Button>
              </div>
              <Select 
                value={selectedImportAccount} 
                onValueChange={setSelectedImportAccount}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white focus:border-blue-400">
                  <SelectValue placeholder="Choose your trading account for CSV import" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  {accounts?.map((account) => (
                    <SelectItem key={account.id} value={account.id.toString()} className="text-white hover:bg-gray-600">
                      <div className="flex items-center justify-between w-full">
                        <span>{account.name}</span>
                        <Badge variant="outline" className="ml-2 text-xs">
                          {account.type}
                        </Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedImportAccount && (
                <p style={{color: '#22c55e', fontSize: '0.875rem', marginTop: '0.5rem'}}>
                  ✓ Selected: {accounts?.find(acc => acc.id.toString() === selectedImportAccount)?.name}
                </p>
              )}
            </div>
            
            {!selectedImportAccount && (
              <div className="bg-yellow-600/20 border border-yellow-600 rounded-lg p-3">
                <div className="flex items-center gap-2">
                  <AlertCircle className={`w-4 h-4 ${getPercentageColor(75).textColor}`} />
                  <span className={`text-sm ${getPercentageColor(75).textColor}`}>Please select an account before uploading files</span>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Universal CSV Import Section */}
      <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/30">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Upload className="w-6 h-6 text-purple-400" />
            <div>
              <CardTitle className="text-purple-400">Universal CSV Import System</CardTitle>
              <div className="flex items-center gap-2 mt-1">
                <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs">
                  🤖 AI-Powered Detection
                </Badge>
                <Badge variant="outline" className="text-purple-400 border-purple-400 text-xs">
                  37+ Brokers Supported
                </Badge>
              </div>
            </div>
          </div>
          <p className="text-gray-400">
            Automatically detects and imports from Interactive Brokers, ThinkorSwim, MetaTrader, NinjaTrader, Tradovate, Robinhood, TradingView, and 30+ other platforms
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Select CSV or Excel File
              </label>
              <Input
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={handleFileChange}
            disabled={!selectedImportAccount}
            className={`bg-gray-700 border-gray-600 text-white file:bg-blue-600 file:text-white file:border-0 file:rounded file:px-3 file:py-1 ${
              !selectedImportAccount ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          />
          {!selectedImportAccount && (
            <p className={`text-xs mt-1 ${getPercentageColor(75).textColor}`}>Select an account first</p>
          )}
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Detected Format
          </label>
          <div className="p-3 bg-gray-700 rounded-md flex items-center">
            {csvFormat === 'position-history' ? (
              <><CheckCircle style={{color: '#22c55e'}} className="h-4 w-4 mr-2" />
              <Badge className="bg-green-600 text-white">✅ Position History CSV</Badge></>
            ) : csvFormat === 'unknown' ? (
              <><AlertCircle style={{color: '#ef4444'}} className="h-4 w-4 mr-2" />
              <Badge variant="destructive">❌ Unknown Format</Badge></>
            ) : (
              <><AlertCircle className="h-4 w-4 text-yellow-400 mr-2" />
              <Badge variant="secondary">{csvFormat}</Badge></>
            )}
          </div>
        </div>
          </div>
        </CardContent>
      </Card>

      {/* Format Information */}
      {totalRowCount > 0 && (
        <div className="bg-blue-600/20 border border-blue-600 rounded-lg p-4">
          <div className="flex items-start">
            <CheckCircle className="h-5 w-5 text-blue-400 mr-3 mt-0.5" />
            <div>
              <h4 className="text-blue-400 font-medium">📊 File Analysis Complete</h4>
              <p className="text-sm text-gray-300 mt-1">
                Found <strong className="text-white">{totalRowCount}</strong> total rows in your Excel file
              </p>
              <p className="text-xs text-blue-300 mt-1">
                Showing {Math.min(10, previewData.length)} sample records below
              </p>
              {csvFormat !== 'unknown' && (
                <div className="mt-2">
                  <p className="text-sm text-green-300">
                    ✅ Format detected as: <strong>{formatInfo.name}</strong>
                  </p>
                  <ul className="text-xs text-gray-400 mt-2 space-y-1">
                    {formatInfo.features.map((feature, index) => (
                      <li key={index}>• {feature}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {csvFormat === 'unknown' && csvHeaders.length > 0 && (
        <div className="bg-yellow-600/20 border border-yellow-600 rounded-lg p-4">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-yellow-400 mr-3 mt-0.5" />
            <div>
              <h4 className="text-yellow-400 font-medium">⚠️ CSV Format Not Recognized</h4>
              <div className="text-sm text-gray-300 mt-2">
                <p><strong>Detected columns:</strong> {csvHeaders.slice(0, 5).join(', ')}{csvHeaders.length > 5 ? '...' : ''}</p>
                <p className="mt-2"><strong>Supported formats:</strong></p>
                <ul className="ml-4 mt-1 space-y-1">
                  <li>• <strong>Standard Export:</strong> Must have 'Account', 'Date/Time', 'Symbol', 'Side', 'Quantity', 'Price'</li>
                  <li>• <strong>Position History:</strong> Must have 'Position ID', 'Bought Timestamp', 'Sold Timestamp'</li>
                  <li>• <strong>Performance:</strong> Must have 'buyFillId', 'sellFillId', 'boughtTimestamp'</li>
                  <li>• <strong>Orders:</strong> Must have 'Order ID', 'Fill Time', 'B/S'</li>
                  <li>• <strong>Fills:</strong> Must have 'Fill ID', 'Order ID', 'Timestamp'</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Preview Section */}
      {previewData.length > 0 && csvFormat !== 'unknown' && (
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-gray-300 flex items-center">
            <FileText className="h-4 w-4 mr-2" />
            Preview Data (Showing {previewData.length} of {totalRowCount} total records)
          </h4>
          
          {previewData.map((row, index) => {
            const boughtTime = new Date(row['Bought Timestamp']);
            const soldTime = new Date(row['Sold Timestamp']);
            const isShort = soldTime < boughtTime;
            
            return (
              <div key={index} className="bg-gray-800 border border-gray-700 rounded-lg p-3">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                  <div>
                    <span className="text-gray-400">Contract:</span>
                    <div className="font-mono text-white">{row['Contract']} → {convertContractToSymbol(row['Contract'])}</div>
                  </div>
                  <div>
                    <span className="text-gray-400">Direction:</span>
                    <div style={{color: isShort ? '#ef4444' : '#22c55e', fontWeight: '500'}}>
                      {isShort ? 'SHORT' : 'LONG'}
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-400">Entry Time:</span>
                    <div className="font-mono text-white text-xs">
                      {isShort ? row['Sold Timestamp'] : row['Bought Timestamp']}
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-400">P&L:</span>
                    <div className={`font-medium ${getUniversalValueColor(parseFloat(row['P/L']) || 0, 'pnl').textColor}`}>
                      ${row['P/L']}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Enhanced Import Stats with AI Detection Results */}
      {importStats && (
        <div className="bg-gradient-to-br from-blue-600/20 to-purple-600/20 border border-blue-600 rounded-lg p-4">
          <h4 className="text-blue-400 font-medium mb-2 flex items-center gap-2">
            📊 Import Statistics
            {importStats.confidence && (
              <Badge className="bg-purple-600 text-white text-xs">
                🤖 {importStats.confidence}% AI Confidence
              </Badge>
            )}
            {importStats.brokerDetected && (
              <Badge variant="outline" className="text-green-400 border-green-400 text-xs">
                {getFormatInfo(importStats.brokerDetected).icon} {getFormatInfo(importStats.brokerDetected).name}
              </Badge>
            )}
          </h4>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
            <div>
              <div className="text-gray-400">Total Imported</div>
              <div className="text-xl font-bold text-white">{importStats.imported}</div>
            </div>
            <div>
              <div className="text-gray-400">Long Trades</div>
              <div className={`text-xl font-bold ${getUniversalValueColor(importStats.longTrades, 'profit').textColor}`}>{importStats.longTrades}</div>
            </div>
            <div>
              <div className="text-gray-400">Short Trades</div>
              <div className={`text-xl font-bold ${getUniversalValueColor(importStats.shortTrades > 0 ? -1 : 0, 'pnl').textColor}`}>{importStats.shortTrades}</div>
            </div>
            {importStats.totalPnL !== undefined && (
              <div>
                <div className="text-gray-400">Total P&L</div>
                <div className={`text-xl font-bold ${getUniversalValueColor(importStats.totalPnL, 'pnl').textColor}`}>
                  ${importStats.totalPnL.toFixed(2)}
                </div>
              </div>
            )}
            {importStats.winRate !== undefined && (
              <div>
                <div className="text-gray-400">Win Rate</div>
                <div className={`text-xl font-bold ${getUniversalValueColor(importStats.winRate, 'profit').textColor}`}>
                  {importStats.winRate.toFixed(1)}%
                </div>
              </div>
            )}
            <div>
              <div className="text-gray-400">Errors</div>
              <div className="text-xl font-bold text-yellow-400">{importStats.errors}</div>
            </div>
          </div>
          {importStats.errorMessage && (
            <div className="mt-3 p-2 bg-red-600/20 border border-red-600 rounded text-red-300 text-sm">
              Error: {importStats.errorMessage}
            </div>
          )}
        </div>
      )}

      {/* AI-Powered Import Button */}
      <Button 
        onClick={handleUpload}
        disabled={!csvFile || isUploading || !selectedImportAccount}
        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-600 disabled:to-gray-600 shadow-lg transform transition-all duration-200 hover:scale-105"
        size="lg"
      >
        {isUploading ? (
          <>
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
            🤖 AI Processing {formatInfo.name}...
          </>
        ) : !selectedImportAccount ? (
          <>
            <AlertCircle className="mr-2 h-4 w-4" />
            Select Account to Import
          </>
        ) : (
          <>
            <Upload className="mr-2 h-4 w-4" />
            🤖 Universal Import ({totalRowCount} Records) to {accounts?.find(acc => acc.id.toString() === selectedImportAccount)?.name}
          </>
        )}
      </Button>
      
      {/* Supported Brokers Info */}
      <Card className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-300 text-sm flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            Supported Trading Platforms & Brokers
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div>
              <h5 className="font-medium text-blue-400 mb-2">Traditional Brokers (12)</h5>
              <div className="space-y-1 text-gray-400">
                <div>🏦 Interactive Brokers</div>
                <div>📈 ThinkorSwim</div>
                <div>🤖 Robinhood</div>
                <div>💼 E*TRADE</div>
                <div>🏛️ Charles Schwab</div>
                <div>🔷 Fidelity</div>
                <div>🌐 Webull</div>
                <div>₿ Coinbase Pro</div>
                <div>🐙 Kraken</div>
                <div>🔶 Binance</div>
                <div>🎯 Tastytrade</div>
                <div>🦙 Alpaca</div>
              </div>
            </div>
            <div>
              <h5 className="font-medium text-purple-400 mb-2">Trading Platforms (19)</h5>
              <div className="space-y-1 text-gray-400">
                <div>📊 MetaTrader 4/5</div>
                <div>🥷 NinjaTrader</div>
                <div>🚂 TradeStation</div>
                <div>📺 TradingView</div>
                <div>⚡ cTrader</div>
                <div>🏪 JForex</div>
                <div>💹 TWS</div>
                <div>💎 Sterling Trader Pro</div>
                <div>⚖️ DAS Trader</div>
                <div>🏃 SpeedTrader</div>
                <div>💨 Lightspeed</div>
                <div>🎯 CenterPoint</div>
                <div>⚔️ Eris X</div>
                <div>📊 Volfix</div>
                <div>📚 Bookmap</div>
                <div>🌊 Quantower</div>
                <div>🎵 Rithmic</div>
                <div>And 2+ more...</div>
              </div>
            </div>
            <div>
              <h5 className="font-medium text-green-400 mb-2">Futures & Specialized (6)</h5>
              <div className="space-y-1 text-gray-400">
                <div>🌾 Tradovate</div>
                <div>🔌 AMP Futures</div>
                <div>✨ Advantage Futures</div>
                <div>🚀 Bybit</div>
                <div>⚡ BitMEX</div>
                <div>🎭 Alpha Ticks</div>
              </div>
            </div>
          </div>
          <div className="mt-4 p-3 bg-purple-600/20 rounded-lg border border-purple-600/30">
            <p className="text-xs text-purple-300">
              <strong>🤖 AI-Powered Detection:</strong> Don't see your broker listed? Our AI system automatically detects and processes most CSV/Excel formats. Simply upload your file and let the system analyze it!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

import TradeEntry from "@/components/trade-entry";
// Note: Using PositionHistoryCsvImport component directly in this file instead of AutomaticCsvImport

export default function Trades() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedAccount, setSelectedAccount] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("date");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [activeTab, setActiveTab] = useState<string>("view");
  const [location] = useLocation();
  const [editingTradeId, setEditingTradeId] = useState<number | null>(null);
  const [editingLink, setEditingLink] = useState<string>("");
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  // Check if we should open the "Add Trade" tab automatically
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('tab') === 'add') {
      setActiveTab('add');
    }
  }, [location]);

  const { data: trades, isLoading: tradesLoading } = useQuery<Trade[]>({
    queryKey: ['/api/trades'],
  });

  const { data: accounts } = useQuery<Account[]>({
    queryKey: ['/api/accounts'],
  });

  const queryClient = useQueryClient();

  // Mutation for updating trade TradingView link
  const updateTradeMutation = useMutation({
    mutationFn: async ({ id, tradingViewLink }: { id: number; tradingViewLink: string }) => {
      return await apiRequest(`/api/trades/${id}`, 'PUT', { tradingViewLink });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
      setEditingTradeId(null);
      setEditingLink("");
    },
    onError: (error) => {
      console.error('Error updating trade:', error);
      alert('Failed to update trade link');
    }
  });

  const startEditing = (trade: Trade) => {
    setEditingTradeId(trade.id);
    setEditingLink(trade.tradingViewLink || "");
  };

  const saveTradeLink = () => {
    if (editingTradeId) {
      updateTradeMutation.mutate({ 
        id: editingTradeId, 
        tradingViewLink: editingLink.trim() 
      });
    }
  };

  const cancelEditing = () => {
    setEditingTradeId(null);
    setEditingLink("");
  };

  const openTradeDetail = (trade: Trade) => {
    setSelectedTrade(trade);
    setIsDetailModalOpen(true);
  };

  const closeTradeDetail = () => {
    setSelectedTrade(null);
    setIsDetailModalOpen(false);
  };

  // Filter and sort trades
  const filteredTrades = useMemo(() => {
    if (!trades) return [];
    
    let filtered = trades.filter(trade => {
      const matchesSearch = 
        trade.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
        trade.orderId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (trade.notes?.toLowerCase().includes(searchTerm.toLowerCase()) ?? false);
      
      const matchesAccount = selectedAccount === "all" || trade.accountId.toString() === selectedAccount;
      
      // Fix status filtering - determine result based on P&L
      let matchesStatus = true;
      if (selectedStatus !== "all") {
        if (selectedStatus === "win" && trade.pnl <= 0) matchesStatus = false;
        if (selectedStatus === "loss" && trade.pnl >= 0) matchesStatus = false;  
        if (selectedStatus === "breakeven" && trade.pnl !== 0) matchesStatus = false;
      }
      
      return matchesSearch && matchesAccount && matchesStatus;
    });

    // Sort trades
    filtered.sort((a, b) => {
      let aValue, bValue;
      
      switch (sortBy) {
        case "date":
          aValue = new Date(a.date).getTime();
          bValue = new Date(b.date).getTime();
          break;
        case "pnl":
          aValue = a.pnl;
          bValue = b.pnl;
          break;
        case "symbol":
          aValue = a.symbol;
          bValue = b.symbol;
          break;
        default:
          aValue = a.id;
          bValue = b.id;
      }
      
      if (aValue < bValue) return sortOrder === "asc" ? -1 : 1;
      if (aValue > bValue) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });

    return filtered;
  }, [trades, searchTerm, selectedAccount, selectedStatus, sortBy, sortOrder]);

  const getAccountName = (accountId: number) => {
    return accounts?.find(acc => acc.id === accountId)?.name || `Account ${accountId}`;
  };

  const exportToCSV = () => {
    if (!filteredTrades.length) return;
    
    const headers = [
      "Date", "Entry Time", "Exit Time", "Duration", "Account", "Symbol", "Side", 
      "Quantity", "Entry Price", "Exit Price", "P&L", "Status", "Order ID", 
      "Initial SL Price", "Initial TP Price", "Final SL Price", "Final TP Price", 
      "Notes", "TradingView Link"
    ];
    
    const csvContent = [
      headers.join(","),
      ...filteredTrades.map(trade => [
        trade.date,
        formatTimeForCSV(trade.fillTime),
        formatTimeForCSV(trade.exitTime),
        calculateDurationForCSV(trade),
        `"${getAccountName(trade.accountId)}"`, // Quoted to handle spaces in account names
        trade.symbol,
        trade.side,
        trade.quantity,
        trade.entryPrice,
        trade.exitPrice || "",
        trade.pnl,
        trade.status,
        trade.orderId || "",
        trade.initialStopLoss || "",
        trade.initialTakeProfit || "",
        trade.finalStopLoss || "",
        trade.finalTakeProfit || "",
        `"${(trade.notes || "").replace(/"/g, '""')}"`, // Escape quotes in notes
        trade.tradingViewLink || ""
      ].join(","))
    ].join("\n");
    
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `trades_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (tradesLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Loading trades...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-bg text-white p-6">
      <div className="space-y-6">
      <header className="border-b border-gray-800 bg-dark-bg pb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gradient-rainbow">
              Trades Log
            </h1>
            <p className="text-gray-400 mt-2">Add new trades manually or view existing trading activity</p>
          </div>
        </div>
      </header>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-gray-800">
          <TabsTrigger value="view" className="text-white data-[state=active]:bg-blue-600">
            View All Trades
          </TabsTrigger>
          <TabsTrigger value="add" className="text-white data-[state=active]:bg-green-600">
            <Plus className="mr-2 h-4 w-4" />
            Add Trade
          </TabsTrigger>
        </TabsList>

        <TabsContent value="add" className="space-y-6">
          {/* CSV Import Section */}
          <Card className="bg-dark-card border-dark-border">
            <CardHeader>
              <CardTitle className="text-white">Universal CSV Import</CardTitle>
              <p className="text-gray-400">Import trades from any broker: Tradovate, MT4/5, Rithmic, CQG, NinjaTrader, Interactive Brokers, and more. For complete timing data, use Performance CSV exports when available.</p>
            </CardHeader>
            <CardContent>
              <UniversalCsvImport accounts={accounts || []} />
            </CardContent>
          </Card>

          {/* Manual Entry Section */}
          <Card className="bg-dark-card border-dark-border">
            <CardHeader>
              <CardTitle className="text-white">Manual Trade Entry</CardTitle>
              <p className="text-gray-400">Enter trade details manually for precise record keeping</p>
            </CardHeader>
            <CardContent>
              <TradeEntry accounts={accounts || []} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="view" className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-white">All Trades</h2>
            <div className="flex gap-2">
              {/* Show data quality warning if there are trades with missing exit times */}
              {filteredTrades.some(trade => trade.status === 'closed' && trade.exitPrice && !trade.exitTime) && (
                <div className="bg-yellow-600/20 border border-yellow-600 rounded px-3 py-1 text-yellow-400 text-sm">
                  ⚠️ Some trades missing exit timestamps
                </div>
              )}
              <Button 
                onClick={async () => {
                  try {
                    const response = await fetch('/api/trades/reprocess-sltp', { 
                      method: 'POST',
                      headers: {
                        'Content-Type': 'application/json'
                      },
                      credentials: 'include'
                    });
                    const result = await response.json();
                    if (result.success) {
                      // Invalidate trades cache to show updated SL/TP values
                      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
                      console.log(`✅ Successfully updated ${result.updatedCount} trades`);
                    } else {
                      console.error('Failed to reprocess trades:', result.message);
                    }
                  } catch (error) {
                    console.error('Reprocessing error:', error);
                  }
                }}
                className="bg-green-600 hover:bg-green-700"
              >
                Update SL/TP Analysis
              </Button>
              <Button onClick={exportToCSV} className="bg-blue-600 hover:bg-blue-700">
                <Download className="mr-2 h-4 w-4" />
                Export CSV
              </Button>
            </div>
          </div>

      {/* Filters */}
      <Card className="bg-dark-card border-dark-border">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Filter className="mr-2 h-5 w-5" />
            Filters & Search
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search symbol, order ID, notes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-700 border-gray-600 text-white"
              />
            </div>
            
            <Select value={selectedAccount} onValueChange={setSelectedAccount}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="All Accounts" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="all" className="text-white">All Accounts</SelectItem>
                {accounts?.map(account => (
                  <SelectItem key={account.id} value={account.id.toString()} className="text-white">
                    {account.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="all" className="text-white">All Status</SelectItem>
                <SelectItem value="win" className="text-white">Wins</SelectItem>
                <SelectItem value="loss" className="text-white">Losses</SelectItem>
                <SelectItem value="breakeven" className="text-white">Breakeven</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="date" className="text-white">Date</SelectItem>
                <SelectItem value="pnl" className="text-white">P&L</SelectItem>
                <SelectItem value="symbol" className="text-white">Symbol</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={sortOrder} onValueChange={(value: "asc" | "desc") => setSortOrder(value)}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Order" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="desc" className="text-white">Newest First</SelectItem>
                <SelectItem value="asc" className="text-white">Oldest First</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-dark-card border-dark-border">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-white">{filteredTrades.length}</div>
            <div className="text-sm text-gray-400">Total Trades</div>
          </CardContent>
        </Card>
        <Card className="bg-dark-card border-dark-border">
          <CardContent className="p-4">
            <div className={`text-2xl font-bold ${getUniversalValueColor(filteredTrades.reduce((sum, trade) => sum + Math.max(0, trade.pnl), 0), 'profit').textColor}`}>
              {formatCurrency(filteredTrades.reduce((sum, trade) => sum + Math.max(0, trade.pnl), 0))}
            </div>
            <div className="text-sm text-gray-400">Total Wins</div>
          </CardContent>
        </Card>
        <Card className="bg-dark-card border-dark-border">
          <CardContent className="p-4">
            <div className={`text-2xl font-bold ${getUniversalValueColor(-Math.abs(filteredTrades.reduce((sum, trade) => sum + Math.min(0, trade.pnl), 0)), 'pnl').textColor}`}>
              {formatCurrency(Math.abs(filteredTrades.reduce((sum, trade) => sum + Math.min(0, trade.pnl), 0)))}
            </div>
            <div className="text-sm text-gray-400">Total Losses</div>
          </CardContent>
        </Card>
        <Card className="bg-dark-card border-dark-border">
          <CardContent className="p-4">
            <div className={`text-2xl font-bold ${getUniversalValueColor(filteredTrades.reduce((sum, trade) => sum + trade.pnl, 0), 'pnl').textColor}`}>
              {formatCurrency(filteredTrades.reduce((sum, trade) => sum + trade.pnl, 0))}
            </div>
            <div className="text-sm text-gray-400">Net P&L</div>
          </CardContent>
        </Card>
      </div>

      {/* Trades Table */}
      <Card className="bg-dark-card border-dark-border">
        <CardHeader>
          <CardTitle className="text-white">Trade History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Date</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Time</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Duration</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Account</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Symbol</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Side</th>
                  <th className="text-right py-3 px-4 text-gray-400 font-medium">Quantity</th>
                  <th className="text-right py-3 px-4 text-gray-400 font-medium">Entry</th>
                  <th className="text-right py-3 px-4 text-gray-400 font-medium">Exit</th>
                  <th className="text-right py-3 px-4 text-gray-400 font-medium">P&L</th>
                  <th className="text-center py-3 px-4 text-gray-400 font-medium">Result</th>
                  <th className="text-right py-3 px-4 text-gray-400 font-medium">Initial SL Price</th>
                  <th className="text-right py-3 px-4 text-gray-400 font-medium">Initial TP Price</th>
                  <th className="text-right py-3 px-4 text-gray-400 font-medium">Final SL Price</th>
                  <th className="text-right py-3 px-4 text-gray-400 font-medium">Final TP Price</th>
                  <th className="text-center py-3 px-4 text-gray-400 font-medium">Price Chart</th>
                  <th className="text-center py-3 px-4 text-gray-400 font-medium">Planned Trade Link</th>
                </tr>
              </thead>
              <tbody>
                {filteredTrades.map((trade) => (
                  <tr 
                    key={trade.id} 
                    className="border-b border-gray-800 hover:bg-gray-800/50 cursor-pointer"
                    onClick={() => openTradeDetail(trade)}
                  >
                    <td className="py-3 px-4 text-gray-200">{formatDate(trade.date)}</td>
                    <td className="py-3 px-4 text-gray-300">
                      <div className="space-y-1">
                        <div className={`text-xs font-medium ${getUniversalValueColor(1, 'profit').textColor}`}>Entry:</div>
                        <div>
                          {trade.fillTime ? new Date(trade.fillTime).toLocaleTimeString('en-US', { 
                            hour: '2-digit', 
                            minute: '2-digit', 
                            hour12: false 
                          }) : '-'}
                        </div>
                        <div className={`text-xs font-medium ${getUniversalValueColor(-1, 'pnl').textColor}`}>Exit:</div>
                        <div>
                          {trade.exitTime ? new Date(trade.exitTime).toLocaleTimeString('en-US', { 
                            hour: '2-digit', 
                            minute: '2-digit', 
                            hour12: false 
                          }) : (trade.status === 'open' ? (
                            <span className="text-blue-400">Open</span>
                          ) : (
                            <span className="text-yellow-400 text-xs">Not recorded</span>
                          ))}
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-gray-300">
                      {(() => {
                        // Check if we have entry time
                        if (!trade.fillTime) return 'No entry time';
                        
                        const entryTime = new Date(trade.fillTime);
                        let exitTime;
                        
                        // Priority 1: Use actual exitTime if available
                        if (trade.exitTime) {
                          exitTime = new Date(trade.exitTime);
                        }
                        // Priority 2: For closed trades without exitTime, indicate missing data
                        else if (trade.status === 'closed' && trade.exitPrice) {
                          return (
                            <span className="text-yellow-400 text-xs">
                              Exit time not recorded
                            </span>
                          );
                        }
                        // Priority 3: Open trades show "Open"
                        else {
                          return trade.status === 'open' ? (
                            <span className="text-blue-400">Currently open</span>
                          ) : 'No timing data';
                        }
                        
                        // Calculate actual duration from real timestamps
                        const durationMs = exitTime.getTime() - entryTime.getTime();
                        const durationMinutes = Math.max(1, Math.floor(durationMs / (1000 * 60)));
                        
                        if (durationMinutes < 60) {
                          return `${durationMinutes}m`;
                        } else if (durationMinutes < 1440) { // Less than 24 hours
                          const hours = Math.floor(durationMinutes / 60);
                          const mins = durationMinutes % 60;
                          return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
                        } else {
                          const days = Math.floor(durationMinutes / 1440);
                          const hours = Math.floor((durationMinutes % 1440) / 60);
                          return hours > 0 ? `${days}d ${hours}h` : `${days}d`;
                        }
                      })()}
                    </td>
                    <td className="py-3 px-4 text-gray-200">{getAccountName(trade.accountId)}</td>
                    <td className="py-3 px-4 text-gray-100 font-medium">{trade.symbol}</td>
                    <td className="py-3 px-4">
                      <Badge 
                        variant={trade.side === 'buy' ? 'default' : 'secondary'}
                        className={trade.side === 'buy' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}
                      >
                        {trade.side.toUpperCase()}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-right text-gray-200">{trade.quantity}</td>
                    <td className="py-3 px-4 text-right text-gray-200">{formatPrice(trade.entryPrice)}</td>
                    <td className="py-3 px-4 text-right text-gray-200">
                      {trade.exitPrice ? formatPrice(trade.exitPrice) : '-'}
                    </td>
                    <td className={`py-3 px-4 text-right font-medium ${
                      getUniversalValueColor(trade.pnl, 'pnl').textColor
                    }`}>
                      {trade.pnl >= 0 ? '+' : '-'}{formatCurrency(Math.abs(trade.pnl))}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <Badge 
                        variant={trade.pnl > 0 ? 'default' : trade.pnl < 0 ? 'destructive' : 'secondary'}
                        className={
                          trade.pnl > 0 ? 'bg-green-600 text-white' :
                          trade.pnl < 0 ? 'bg-red-600 text-white' :
                          'bg-gray-600 text-white'
                        }
                      >
                        {trade.pnl > 0 ? 'WIN' : trade.pnl < 0 ? 'LOSS' : 'BREAKEVEN'}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-right text-gray-300">
                      {trade.initialStopLoss ? formatPrice(trade.initialStopLoss) : 
                        <span className="text-gray-500 text-sm">—</span>}
                    </td>
                    <td className="py-3 px-4 text-right text-gray-300">
                      {trade.initialTakeProfit ? formatPrice(trade.initialTakeProfit) : 
                        <span className="text-gray-500 text-sm">—</span>}
                    </td>
                    <td className="py-3 px-4 text-right text-gray-300">
                      {trade.finalStopLoss ? formatPrice(trade.finalStopLoss) : 
                        <span className="text-gray-500 text-sm">—</span>}
                    </td>
                    <td className="py-3 px-4 text-right text-gray-300">
                      {trade.finalTakeProfit ? formatPrice(trade.finalTakeProfit) : 
                        <span className="text-gray-500 text-sm">—</span>}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex flex-col gap-1">
                        {trade.tradeImage && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => trade.tradeImage && window.open(trade.tradeImage, '_blank')}
                            className="text-purple-400 border-purple-400 hover:bg-purple-400/20"
                          >
                            🖼️ Trade Image
                          </Button>
                        )}
                        {trade.tradingViewLink && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => trade.tradingViewLink && window.open(trade.tradingViewLink, '_blank')}
                            className="text-blue-400 border-blue-400 hover:bg-blue-400/20"
                          >
                            📈 TradingView
                          </Button>
                        )}
                        {!trade.tradeImage && !trade.tradingViewLink && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => window.open(`https://www.tradingview.com/chart/?symbol=${trade.symbol}`, '_blank')}
                            className="text-blue-400 border-blue-400 hover:bg-blue-400/20"
                          >
                            📈 View Chart
                          </Button>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      {editingTradeId === trade.id ? (
                        <div className="flex flex-col gap-2">
                          <Input
                            value={editingLink}
                            onChange={(e) => setEditingLink(e.target.value)}
                            placeholder="Enter TradingView link..."
                            className="text-xs h-8"
                          />
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              onClick={saveTradeLink}
                              disabled={updateTradeMutation.isPending}
                              className="bg-green-600 hover:bg-green-700 h-6 px-2"
                            >
                              <Save className="h-3 w-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={cancelEditing}
                              className="h-6 px-2"
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col gap-1">
                          {trade.tradingViewLink && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => window.open(trade.tradingViewLink || '', '_blank')}
                              className="text-blue-400 border-blue-400 hover:bg-blue-400/20 h-6 text-xs"
                            >
                              📈 View Plan
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => startEditing(trade)}
                            className="text-yellow-400 border-yellow-400 hover:bg-yellow-400/20 h-6 text-xs"
                          >
                            <Edit3 className="h-3 w-3 mr-1" />
                            {trade.tradingViewLink ? 'Edit' : 'Add'} Link
                          </Button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {filteredTrades.length === 0 && (
              <div className="text-center py-8 text-gray-400">
                No trades found matching your filters.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
        </TabsContent>
      </Tabs>

      {/* Trade Detail Modal */}
      <TradeDetailModal 
        trade={selectedTrade}
        isOpen={isDetailModalOpen}
        onClose={closeTradeDetail}
      />
      </div>
    </div>
  );
}