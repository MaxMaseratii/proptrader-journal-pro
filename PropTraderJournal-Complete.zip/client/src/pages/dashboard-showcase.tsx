import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { EquityChart, MonthlyPerformanceChart } from "@/components/chart-components";
import { useLocation } from "wouter";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Target, 
  Shield, 
  Calendar,
  PlusCircle,
  BookOpen,
  BarChart3,
  Activity,
  Award,
  AlertTriangle,
  Upload,
  Filter,
  Clock,
  CheckCircle,
  XCircle
} from "lucide-react";
import { Account, Trade, JournalEntry } from "@shared/schema";

export default function DashboardShowcase() {
  const [, setLocation] = useLocation();
  
  const { data: accounts = [] } = useQuery<Account[]>({
    queryKey: ["/api/accounts"],
  });

  const { data: trades = [] } = useQuery<Trade[]>({
    queryKey: ["/api/trades"],
  });

  const { data: journalEntries = [] } = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal-entries"],
  });

  // Calculate portfolio metrics
  const totalPortfolioValue = accounts.reduce((sum, acc) => sum + acc.startingBalance, 0);
  const totalInvested = accounts.reduce((sum, acc) => sum + (acc.accountCost || 0) + (acc.activationCost || 0), 0);
  const totalPnL = trades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
  const totalPnLPercentage = accounts.length > 0 
    ? (totalPnL / accounts.reduce((sum, acc) => sum + acc.startingBalance, 0)) * 100 
    : 0;

  // Account status counts
  const activeAccounts = accounts.filter(acc => acc.status === 'active').length;
  const fundedAccounts = accounts.filter(acc => acc.status === 'funded').length;
  const challengeAccounts = accounts.filter(acc => acc.type === 'challenge').length;

  // Trading performance metrics
  const winningTrades = trades.filter(trade => trade.pnl > 0).length;
  const totalTrades = trades.length;
  const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0;
  const totalTradingPnL = trades.reduce((sum, trade) => sum + trade.pnl, 0);

  // Recent trades for showcase
  const recentTrades = trades.slice(0, 5);

  // Generate equity curve data from actual trades
  const equityData = trades.length > 0 ? trades
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .reduce((acc, trade, index) => {
      const previousBalance = index === 0 ? (accounts?.[0]?.startingBalance || 0) : acc[index - 1].balance;
      const newBalance = previousBalance + (trade.pnl || 0);
      acc.push({
        date: new Date(trade.date).toISOString().split('T')[0],
        balance: newBalance
      });
      return acc;
    }, [] as { date: string; balance: number }[]) : [];

  // Generate monthly data from actual trades
  const monthlyData = trades.length > 0 ? Array.from(
    trades.reduce((acc, trade) => {
      const month = new Date(trade.date).toLocaleDateString('en-US', { month: 'short' });
      const existing = acc.get(month) || 0;
      acc.set(month, existing + (trade.pnl || 0));
      return acc;
    }, new Map<string, number>()),
    ([month, pnl]) => ({ month, pnl })
  ) : [];

  return (
    <div className="p-6 space-y-8 bg-prop-gradient-main min-h-screen">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gradient-rainbow mb-2">Trading Dashboard</h1>
          <p className="text-gray-400">Complete portfolio overview and performance analytics</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <Button 
            variant="outline" 
            className="border-prop-tiffany/20 hover:bg-prop-tiffany/10"
            onClick={() => setLocation('/csv-import')}
          >
            <Upload className="mr-2 h-4 w-4" />
            Import CSV
          </Button>
          <Button 
            className="bg-prop-gradient-gold text-black font-bold hover-scale"
            onClick={() => setLocation('/accounts')}
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Create New Account
          </Button>
        </div>
      </div>

      {/* Account Selection and Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="bg-prop-card border-prop-gold/20">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-prop-gold" />
              <label className="text-sm font-medium text-gray-300">Account Filter</label>
            </div>
            <Select defaultValue="all">
              <SelectTrigger className="mt-2 bg-prop-dark border-prop-gold/20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Accounts ({accounts.length})</SelectItem>
                <SelectItem value="funded">Funded Accounts ({fundedAccounts})</SelectItem>
                <SelectItem value="challenge">Challenge Accounts ({challengeAccounts})</SelectItem>
                <SelectItem value="active">Live Accounts ({activeAccounts})</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-blue/20">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-prop-blue" />
              <label className="text-sm font-medium text-gray-300">Time Period</label>
            </div>
            <Select defaultValue="month">
              <SelectTrigger className="mt-2 bg-prop-dark border-prop-blue/20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="quarter">This Quarter</SelectItem>
                <SelectItem value="year">This Year</SelectItem>
                <SelectItem value="all">All Time</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-green/20">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4 text-prop-green" />
              <label className="text-sm font-medium text-gray-300">View Mode</label>
            </div>
            <Select defaultValue="overview">
              <SelectTrigger className="mt-2 bg-prop-dark border-prop-green/20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="overview">Overview</SelectItem>
                <SelectItem value="detailed">Detailed Analysis</SelectItem>
                <SelectItem value="monthly">Monthly View</SelectItem>
                <SelectItem value="discipline">Discipline Score</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
      </div>

      {/* Portfolio Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-prop-card border-prop-gold/20 hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Total Portfolio Value</p>
                <p className="text-2xl font-bold text-prop-gold">
                  ${totalPortfolioValue.toLocaleString()}
                </p>
                <p className="text-xs text-gray-400 mt-1">Combined accounts</p>
              </div>
              <div className="bg-prop-gradient-gold p-3 rounded-xl">
                <DollarSign className="h-6 w-6 text-black" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-tiffany/20 hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Daily P&L</p>
                <p className="text-2xl font-bold text-prop-pink">-$825</p>
                <p className="text-xs text-gray-400 mt-1">Today's performance</p>
              </div>
              <div className="bg-prop-gradient-pink p-3 rounded-xl">
                <TrendingDown className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-blue/20 hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Avg Win/Loss</p>
                <div className="flex items-center space-x-2 text-lg font-bold">
                  <span className="text-prop-green">$485</span>
                  <span className="text-gray-400">/</span>
                  <span className="text-prop-pink">$312</span>
                </div>
                <p className="text-xs text-gray-400 mt-1">Win vs Loss ratio</p>
              </div>
              <div className="bg-prop-gradient-blue p-3 rounded-xl">
                <BarChart3 className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-green/20 hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Win Rate</p>
                <p className="text-2xl font-bold text-prop-green">{winRate.toFixed(0)}%</p>
                <p className="text-xs text-gray-400 mt-1">{winningTrades} wins / {totalTrades - winningTrades} losses</p>
              </div>
              <div className="bg-prop-gradient-green p-3 rounded-xl">
                <Target className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Secondary Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-prop-card border-prop-tiffany/20 hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">R Factor</p>
                <p className="text-2xl font-bold text-prop-green">1.56</p>
                <p className="text-xs text-gray-400 mt-1">Total Reward / Total Risk ratio</p>
              </div>
              <div className="bg-prop-gradient-tiffany p-3 rounded-xl">
                <BarChart3 className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-pink/20 hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Profit Factor</p>
                <p className="text-2xl font-bold text-prop-blue">2.14</p>
                <p className="text-xs text-gray-400 mt-1">Gross Profit / Gross Loss ratio</p>
              </div>
              <div className="bg-prop-gradient-blue p-3 rounded-xl">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-gold/20 hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Total Trades</p>
                <p className="text-2xl font-bold text-prop-gold">{totalTrades}</p>
                <p className="text-xs text-gray-400 mt-1">This month</p>
              </div>
              <div className="bg-prop-gradient-gold p-3 rounded-xl">
                <Activity className="h-6 w-6 text-black" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Account Balance by Type - Key Feature from Original */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-prop-card border-prop-blue/20 hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Funded Accounts</p>
                <p className="text-2xl font-bold text-prop-blue">
                  ${accounts.filter(acc => acc.status === 'funded').reduce((sum, acc) => sum + acc.startingBalance, 0).toLocaleString()}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  {fundedAccounts} accounts • Payout eligible
                </p>
              </div>
              <div className="bg-prop-gradient-blue p-3 rounded-xl">
                <DollarSign className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-green/20 hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Live Accounts</p>
                <p className="text-2xl font-bold text-prop-green">
                  ${accounts.filter(acc => acc.status === 'active').reduce((sum, acc) => sum + acc.startingBalance, 0).toLocaleString()}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  {activeAccounts} accounts • Payout eligible
                </p>
              </div>
              <div className="bg-prop-gradient-green p-3 rounded-xl">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-gold/20 hover-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Challenge Accounts</p>
                <p className="text-2xl font-bold text-prop-gold">
                  ${accounts.filter(acc => acc.type === 'challenge').reduce((sum, acc) => sum + acc.startingBalance, 0).toLocaleString()}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  {challengeAccounts} accounts • In progress
                </p>
              </div>
              <div className="bg-prop-gradient-gold p-3 rounded-xl">
                <Shield className="h-6 w-6 text-black" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Account Portfolio Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 bg-prop-card border-prop-gold/20 hover-glow">
          <CardHeader>
            <CardTitle className="text-gradient-rainbow flex items-center">
              <BarChart3 className="mr-2 h-5 w-5" />
              Account Portfolio Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {accounts.map((account) => (
                <div key={account.id} className="flex items-center justify-between p-4 bg-prop-gradient-subtle rounded-xl border border-prop-gold/10">
                  <div>
                    <div className="flex items-center space-x-3">
                      <h3 className="font-semibold text-white">{account.name}</h3>
                      <Badge 
                        variant={account.status === 'funded' ? 'default' : 'secondary'}
                        className={`
                          ${account.status === 'funded' ? 'bg-prop-green text-white' : ''}
                          ${account.status === 'active' ? 'bg-prop-blue text-white' : ''}
                          ${account.status === 'challenge' ? 'bg-prop-gold text-black' : ''}
                        `}
                      >
                        {account.status === 'funded' ? 'Funded' : account.type === 'challenge' ? 'Challenge' : 'Active'}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-400">{account.firm}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-white">${account.startingBalance.toLocaleString()}</p>
                    <p className="text-sm text-gray-400">Starting Balance
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-tiffany/20 hover-glow">
          <CardHeader>
            <CardTitle className="text-gradient-rainbow flex items-center">
              <Activity className="mr-2 h-5 w-5" />
              Investment Tracking & Payouts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-prop-gradient-subtle rounded-xl">
                <div className="text-center">
                  <p className="text-gray-400 text-sm">Account Costs</p>
                  <p className="font-bold text-prop-gold">${(totalInvested - 450).toLocaleString()}</p>
                  <p className="text-xs text-gray-500">Purchase costs</p>
                </div>
              </div>
              <div className="p-3 bg-prop-gradient-subtle rounded-xl">
                <div className="text-center">
                  <p className="text-gray-400 text-sm">Activation Fees</p>
                  <p className="font-bold text-prop-blue">$450</p>
                  <p className="text-xs text-gray-500">Activation costs</p>
                </div>
              </div>
            </div>
            
            <div className="p-4 bg-prop-gradient-subtle rounded-xl border border-prop-green/20">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-400">Total Invested</span>
                <span className="font-bold text-white">${totalInvested.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-400">Total Payouts</span>
                <span className="font-bold text-prop-green">$8,750</span>
              </div>
              <div className="h-px bg-gray-600 my-2"></div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400 font-medium">Profitability</span>
                <span className="font-bold text-prop-green">
                  +${(8750 - totalInvested).toLocaleString()}
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-1 text-center">
                {`Profitable • $8,750 vs $${totalInvested.toLocaleString()}`}
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Payout ROI</span>
                <span className="text-sm text-prop-green">
                  +{(((8750 - totalInvested) / totalInvested) * 100).toFixed(1)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Funded Accounts</span>
                <span className="text-sm text-white">{fundedAccounts}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Reset Costs</span>
                <span className="text-sm text-white">$0</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-prop-card border-prop-blue/20 hover-glow">
          <CardHeader>
            <CardTitle className="text-gradient-rainbow">Equity Curve</CardTitle>
          </CardHeader>
          <CardContent>
            <EquityChart data={equityData} />
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-green/20 hover-glow">
          <CardHeader>
            <CardTitle className="text-gradient-rainbow">Monthly Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <MonthlyPerformanceChart data={monthlyData} />
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity & Journal */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-prop-card border-prop-pink/20 hover-glow">
          <CardHeader>
            <CardTitle className="text-gradient-rainbow flex items-center">
              <Award className="mr-2 h-5 w-5" />
              Recent Trades
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentTrades.map((trade) => (
                <div key={trade.id} className="flex items-center justify-between p-3 bg-prop-gradient-subtle rounded-lg border border-prop-gold/10">
                  <div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="text-prop-gold border-prop-gold">
                        {trade.symbol}
                      </Badge>
                      <span className="text-sm text-gray-400">{trade.date}</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {trade.side.toUpperCase()} {trade.quantity} @ {trade.entryPrice}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className={`font-semibold ${trade.pnl >= 0 ? 'text-prop-green' : 'text-prop-pink'}`}>
                      {trade.pnl >= 0 ? '+' : ''}${trade.pnl.toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-tiffany/20 hover-glow">
          <CardHeader>
            <CardTitle className="text-gradient-rainbow flex items-center">
              <BookOpen className="mr-2 h-5 w-5" />
              Daily Journal Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {journalEntries.slice(0, 3).map((entry) => (
                <div key={entry.id} className="p-3 bg-prop-gradient-subtle rounded-lg border border-prop-gold/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-prop-gold font-medium">{entry.date}</span>
                    <Badge variant="outline" className="text-prop-tiffany border-prop-tiffany">
                      Journal
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-300 line-clamp-2">
                    {entry.whatWentRight || entry.improvementPlan}
                  </p>
                </div>
              ))}
              <Button variant="outline" className="w-full border-prop-tiffany text-prop-tiffany hover:bg-prop-tiffany hover:text-black">
                View Full Journal
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Challenge Progress Tracking - Critical Missing Feature */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="bg-prop-card border-prop-blue/20 hover-glow">
          <CardHeader>
            <CardTitle className="text-gradient-rainbow flex items-center">
              <Target className="mr-2 h-5 w-5" />
              Challenge Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-400">Profit Target</span>
                  <span className="text-sm text-prop-green">78%</span>
                </div>
                <Progress value={78} className="h-2" />
                <p className="text-xs text-gray-400 mt-1">$7,800 / $10,000</p>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-400">Max Drawdown</span>
                  <span className="text-sm text-prop-pink">42%</span>
                </div>
                <Progress value={42} className="h-2" />
                <p className="text-xs text-gray-400 mt-1">$2,100 / $5,000</p>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-400">Trading Days</span>
                  <span className="text-sm text-prop-gold">12 / 30</span>
                </div>
                <Progress value={40} className="h-2" />
                <p className="text-xs text-gray-400 mt-1">18 days remaining</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-green/20 hover-glow">
          <CardHeader>
            <CardTitle className="text-gradient-rainbow flex items-center">
              <DollarSign className="mr-2 h-5 w-5" />
              Payout Tracking
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Next Payout</span>
                <span className="text-prop-green font-bold">$2,450</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Payout Date</span>
                <span className="text-white">Nov 15, 2024</span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-gray-400">Split Rate</span>
                <span className="text-prop-gold">80%</span>
              </div>

              <div className="border-t border-gray-600 pt-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Total Payouts</span>
                  <span className="text-prop-green font-bold">$8,750</span>
                </div>
                <p className="text-xs text-gray-400 mt-1">3 payouts this year</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-prop-card border-prop-pink/20 hover-glow">
          <CardHeader>
            <CardTitle className="text-gradient-rainbow flex items-center justify-between">
              <div className="flex items-center">
                <Clock className="mr-2 h-5 w-5" />
                Trade Analysis View
              </div>
              <div className="flex gap-2">
                <Select defaultValue="monthly">
                  <SelectTrigger className="w-32 bg-prop-dark border-prop-pink/20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
                <Select defaultValue="2024">
                  <SelectTrigger className="w-20 bg-prop-dark border-prop-pink/20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2024">2024</SelectItem>
                    <SelectItem value="2023">2023</SelectItem>
                    <SelectItem value="2022">2022</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="october" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-prop-dark">
                <TabsTrigger value="august">Aug</TabsTrigger>
                <TabsTrigger value="september">Sep</TabsTrigger>
                <TabsTrigger value="october">Oct</TabsTrigger>
              </TabsList>
              
              <TabsContent value="october" className="space-y-3 mt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Total Trades</span>
                  <span className="text-white">47</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Win Rate</span>
                  <span className="text-prop-green">64%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Monthly P&L</span>
                  <span className="text-prop-green">+$4,200</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Best Day</span>
                  <span className="text-prop-green">+$890</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Worst Day</span>
                  <span className="text-prop-pink">-$425</span>
                </div>
              </TabsContent>

              <TabsContent value="september" className="space-y-3 mt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Total Trades</span>
                  <span className="text-white">38</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Win Rate</span>
                  <span className="text-prop-green">71%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Monthly P&L</span>
                  <span className="text-prop-green">+$3,100</span>
                </div>
              </TabsContent>

              <TabsContent value="august" className="space-y-3 mt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Total Trades</span>
                  <span className="text-white">29</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Win Rate</span>
                  <span className="text-prop-green">69%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Monthly P&L</span>
                  <span className="text-prop-green">+$2,400</span>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Disciplined Analysis */}
      <Card className="bg-prop-card border-prop-gold/20 hover-glow">
        <CardHeader>
          <CardTitle className="text-gradient-rainbow flex items-center">
            <AlertTriangle className="mr-2 h-5 w-5" />
            Disciplined Trading Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-prop-gradient-subtle rounded-xl">
              <div className="text-3xl font-bold text-prop-green mb-2">95%</div>
              <p className="text-gray-400">Discipline Score</p>
              <p className="text-xs text-prop-green mt-1">Excellent</p>
            </div>
            <div className="text-center p-4 bg-prop-gradient-subtle rounded-xl">
              <div className="text-3xl font-bold text-prop-blue mb-2">2</div>
              <p className="text-gray-400">Rule Violations</p>
              <p className="text-xs text-prop-blue mt-1">This Month</p>
            </div>
            <div className="text-center p-4 bg-prop-gradient-subtle rounded-xl">
              <div className="text-3xl font-bold text-prop-tiffany mb-2">15</div>
              <p className="text-gray-400">Streak Days</p>
              <p className="text-xs text-prop-tiffany mt-1">Following Rules</p>
            </div>
          </div>
          <div className="mt-6 p-4 bg-prop-gradient-subtle rounded-xl border border-prop-green/20">
            <h4 className="font-semibold text-prop-green mb-2">Recent Achievements</h4>
            <ul className="space-y-1 text-sm text-gray-300">
              <li>• Maintained perfect position sizing for 10 consecutive trades</li>
              <li>• No revenge trading incidents in the last 30 days</li>
              <li>• Successfully followed stop-loss rules on all losing trades</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}